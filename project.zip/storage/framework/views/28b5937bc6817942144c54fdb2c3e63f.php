<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; padding: 40px;">
  <div style="max-width: 480px; margin: 0 auto; background: white; border-radius: 16px; padding: 40px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
    <h1 style="text-align: center; font-size: 28px; margin: 0 0 8px; color: #111;">DocNow</h1>
    <p style="text-align: center; color: #666; margin-bottom: 32px;">Appointment Cancelled</p>
    <p>Hi <strong><?php echo e($appointment->patient->user->name); ?></strong>,</p>
    <p>Your appointment with <strong>Dr. <?php echo e($appointment->doctor->user->name); ?></strong> on <strong><?php echo e($appointment->appointment_date); ?></strong> has been cancelled.</p>
    <p style="color: #999; font-size: 13px; margin-top: 24px;">Book a new appointment anytime on DocNow.</p>
  </div>
</body>
</html>
<?php /**PATH /home/herakku/Desktop/mvc/resources/views/emails/appointment-cancelled.blade.php ENDPATH**/ ?>