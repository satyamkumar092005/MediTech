<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; padding: 40px;">
  <div style="max-width: 480px; margin: 0 auto; background: white; border-radius: 16px; padding: 40px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
    <h1 style="text-align: center; font-size: 28px; margin: 0 0 8px; color: #111;">DocNow</h1>
    <p style="text-align: center; color: #666; margin-bottom: 32px;">Appointment Confirmed</p>
    <p>Hi <strong><?php echo e($appointment->patient->user->name); ?></strong>,</p>
    <p>Your appointment with <strong>Dr. <?php echo e($appointment->doctor->user->name); ?></strong> has been confirmed!</p>
    <div style="background: #f8f9fa; border-radius: 12px; padding: 24px; margin: 24px 0;">
      <p><strong>Date:</strong> <?php echo e($appointment->appointment_date); ?></p>
      <p><strong>Time:</strong> <?php echo e(substr($appointment->start_time, 0, 5)); ?> - <?php echo e(substr($appointment->end_time, 0, 5)); ?></p>
    </div>
    <p style="color: #999; font-size: 13px;">Please log in to join the video consultation at the scheduled time.</p>
  </div>
</body>
</html>
<?php /**PATH /home/herakku/Desktop/mvc/resources/views/emails/appointment-confirmed.blade.php ENDPATH**/ ?>