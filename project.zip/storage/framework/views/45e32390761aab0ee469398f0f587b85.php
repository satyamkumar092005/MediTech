<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; padding: 40px;">
  <div style="max-width: 480px; margin: 0 auto; background: white; border-radius: 16px; padding: 40px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
    <h1 style="text-align: center; font-size: 28px; margin: 0 0 8px; color: #111;">DocNow</h1>
    <p style="text-align: center; color: #666; margin-bottom: 32px;">Verify your email address</p>
    <div style="background: #f8f9fa; border-radius: 12px; padding: 24px; text-align: center;">
      <p style="color: #666; margin: 0 0 16px;">Your verification code</p>
      <div style="font-size: 40px; font-weight: 700; letter-spacing: 12px; color: #111; font-family: monospace;"><?php echo e($otp); ?></div>
      <p style="color: #999; font-size: 14px; margin: 16px 0 0;">This code expires in 10 minutes.</p>
    </div>
    <p style="color: #999; font-size: 13px; text-align: center; margin-top: 32px;">If you didn't create an account, ignore this email.</p>
  </div>
</body>
</html>
<?php /**PATH /home/herakku/Desktop/mvc/resources/views/emails/otp.blade.php ENDPATH**/ ?>