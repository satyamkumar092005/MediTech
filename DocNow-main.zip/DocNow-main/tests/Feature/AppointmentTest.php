<?php

namespace Tests\Feature;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Patient;
use App\Models\Specialization;
use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AppointmentTest extends TestCase
{
    use RefreshDatabase;

    protected Patient $patient;
    protected Doctor $doctor;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolesAndPermissionsSeeder::class);

        $specialization = Specialization::factory()->create();

        $patientUser = User::factory()->create([
            'email' => 'patient@test.com',
            'email_verified_at' => now(),
        ]);
        $patientUser->assignRole('patient');
        $this->patient = Patient::factory()->create(['user_id' => $patientUser->id]);

        $doctorUser = User::factory()->create([
            'email' => 'doctor@test.com',
            'email_verified_at' => now(),
        ]);
        $doctorUser->assignRole('doctor');
        $this->doctor = Doctor::factory()->create([
            'user_id' => $doctorUser->id,
            'specialization_id' => $specialization->id,
        ]);
    }

    public function test_patient_can_book_appointment(): void
    {
        $response = $this->actingAs($this->patient->user)->post('/patient/appointments', [
            'doctor_id' => $this->doctor->id,
            'appointment_date' => now()->addDays(2)->format('Y-m-d'),
            'start_time' => '10:00',
            'end_time' => '10:30',
            'type' => 'virtual',
            'payment_id' => 'promo_test',
            'is_free' => true,
        ]);

        $response->assertSessionHas('success');
        $this->assertDatabaseHas('appointments', [
            'patient_id' => $this->patient->id,
            'doctor_id' => $this->doctor->id,
        ]);
    }

    public function test_patient_can_cancel_own_appointment(): void
    {
        $appointment = Appointment::factory()->create([
            'patient_id' => $this->patient->id,
            'doctor_id' => $this->doctor->id,
            'status' => 'pending',
        ]);

        $response = $this->actingAs($this->patient->user)
            ->patch("/patient/appointments/{$appointment->id}/cancel");

        $response->assertSessionHas('success');
        $this->assertEquals('cancelled', $appointment->fresh()->status);
    }

    public function test_doctor_can_confirm_appointment(): void
    {
        $appointment = Appointment::factory()->create([
            'patient_id' => $this->patient->id,
            'doctor_id' => $this->doctor->id,
            'status' => 'pending',
        ]);

        $response = $this->actingAs($this->doctor->user)
            ->patch("/doctor/appointments/{$appointment->id}/confirm");

        $response->assertSessionHas('success');
        $this->assertEquals('confirmed', $appointment->fresh()->status);
    }

    public function test_doctor_can_complete_appointment(): void
    {
        $appointment = Appointment::factory()->create([
            'patient_id' => $this->patient->id,
            'doctor_id' => $this->doctor->id,
            'status' => 'confirmed',
        ]);

        $response = $this->actingAs($this->doctor->user)
            ->patch("/doctor/appointments/{$appointment->id}/complete");

        $response->assertSessionHas('success');
        $this->assertEquals('completed', $appointment->fresh()->status);
    }
}
