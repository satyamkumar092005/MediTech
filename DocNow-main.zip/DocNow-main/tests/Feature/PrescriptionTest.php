<?php

namespace Tests\Feature;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Patient;
use App\Models\Prescription;
use App\Models\Specialization;
use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PrescriptionTest extends TestCase
{
    use RefreshDatabase;

    protected Patient $patient;
    protected Doctor $doctor;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolesAndPermissionsSeeder::class);

        $specialization = Specialization::factory()->create();

        $patientUser = User::factory()->create([
            'email' => 'patient@test.com',
            'email_verified_at' => now(),
        ]);
        $patientUser->assignRole('patient');
        $this->patient = Patient::factory()->create(['user_id' => $patientUser->id]);

        $doctorUser = User::factory()->create([
            'email' => 'doctor@test.com',
            'email_verified_at' => now(),
        ]);
        $doctorUser->assignRole('doctor');
        $this->doctor = Doctor::factory()->create([
            'user_id' => $doctorUser->id,
            'specialization_id' => $specialization->id,
        ]);
    }

    public function test_doctor_can_write_prescription(): void
    {
        $appointment = Appointment::factory()->create([
            'patient_id' => $this->patient->id,
            'doctor_id' => $this->doctor->id,
        ]);

        $response = $this->actingAs($this->doctor->user)->post('/doctor/prescriptions', [
            'appointment_id' => $appointment->id,
            'notes' => 'Take care',
            'items' => [
                [
                    'medicine_name' => 'Paracetamol',
                    'dosage' => '500mg',
                    'frequency' => '3x daily',
                    'duration' => '5 days',
                ],
            ],
        ]);

        $response->assertSessionHas('success');
        $this->assertDatabaseHas('prescriptions', [
            'appointment_id' => $appointment->id,
        ]);
        $this->assertDatabaseHas('prescription_items', [
            'medicine_name' => 'Paracetamol',
        ]);
    }

    public function test_patient_can_toggle_prescription_fill_status(): void
    {
        $appointment = Appointment::factory()->create([
            'patient_id' => $this->patient->id,
            'doctor_id' => $this->doctor->id,
        ]);

        $prescription = Prescription::factory()->create([
            'appointment_id' => $appointment->id,
            'patient_id' => $this->patient->id,
            'doctor_id' => $this->doctor->id,
            'is_filled' => false,
        ]);

        $this->assertFalse((bool) $prescription->is_filled);

        $response = $this->actingAs($this->patient->user)
            ->patch("/patient/prescriptions/{$prescription->id}/fill");

        $response->assertSessionHas('success');
        $this->assertTrue((bool) $prescription->fresh()->is_filled);
    }
}
