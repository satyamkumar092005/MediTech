<?php

namespace Tests\Feature;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Patient;
use App\Models\Specialization;
use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class RatingTest extends TestCase
{
    use RefreshDatabase;

    protected Patient $patient;
    protected Doctor $doctor;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolesAndPermissionsSeeder::class);

        $specialization = Specialization::factory()->create();

        $patientUser = User::factory()->create([
            'email' => 'patient@test.com',
            'email_verified_at' => now(),
        ]);
        $patientUser->assignRole('patient');
        $this->patient = Patient::factory()->create(['user_id' => $patientUser->id]);

        $doctorUser = User::factory()->create([
            'email' => 'doctor@test.com',
            'email_verified_at' => now(),
        ]);
        $doctorUser->assignRole('doctor');
        $this->doctor = Doctor::factory()->create([
            'user_id' => $doctorUser->id,
            'specialization_id' => $specialization->id,
        ]);
    }

    public function test_patient_can_rate_completed_appointment(): void
    {
        $appointment = Appointment::factory()->create([
            'patient_id' => $this->patient->id,
            'doctor_id' => $this->doctor->id,
            'status' => 'completed',
        ]);

        $response = $this->actingAs($this->patient->user)->post('/patient/ratings', [
            'appointment_id' => $appointment->id,
            'rating' => 5,
            'review' => 'Great doctor!',
        ]);

        $response->assertSessionHas('success');
        $this->assertDatabaseHas('ratings', [
            'appointment_id' => $appointment->id,
            'rating' => 5,
        ]);
    }

    public function test_patient_cannot_rate_uncompleted_appointment(): void
    {
        $appointment = Appointment::factory()->create([
            'patient_id' => $this->patient->id,
            'doctor_id' => $this->doctor->id,
            'status' => 'pending',
        ]);

        $response = $this->actingAs($this->patient->user)->post('/patient/ratings', [
            'appointment_id' => $appointment->id,
            'rating' => 5,
        ]);

        $response->assertSessionHasErrors();
    }
}
