<?php

namespace App\Services;

use App\Models\Appointment;

class CalendarService
{
    public function generateIcs(Appointment $appointment): string
    {
        $start = \Carbon\Carbon::parse($appointment->appointment_date . ' ' . $appointment->start_time)->utc();
        $end = \Carbon\Carbon::parse($appointment->appointment_date . ' ' . $appointment->end_time)->utc();

        $dtStart = $start->format('Ymd\THis\Z');
        $dtEnd = $end->format('Ymd\THis\Z');
        $now = now()->utc()->format('Ymd\THis\Z');
        
        $doctorName = $appointment->doctor->user->name;
        $patientName = $appointment->patient->user->name;
        
        $uid = 'appointment_' . $appointment->id . '@' . request()->getHost();

        return "BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//DocNow//NONSGML v1.0//EN
CALSCALE:GREGORIAN
METHOD:REQUEST
BEGIN:VEVENT
DTSTART:{$dtStart}
DTEND:{$dtEnd}
DTSTAMP:{$now}
UID:{$uid}
CREATED:{$now}
DESCRIPTION:Telemedicine Consultation with {$doctorName}
LAST-MODIFIED:{$now}
LOCATION:Online (DocNow Portal)
SEQUENCE:0
STATUS:CONFIRMED
SUMMARY:Consultation: {$doctorName} and {$patientName}
TRANSP:OPAQUE
END:VEVENT
END:VCALENDAR";
    }
}
