<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Appointment extends Model
{
    use HasFactory;

    protected $fillable = [
        'doctor_id', 'patient_id', 'schedule_id', 'appointment_date',
        'start_time', 'end_time', 'type', 'status', 'notes', 'meeting_link',
        'consultation_summary', 'payment_id', 'razorpay_order_id', 'razorpay_signature',
        'coupon_id'
    ];

    public function doctor()
    {
        return $this->belongsTo(Doctor::class);
    }

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    public function schedule()
    {
        return $this->belongsTo(Schedule::class);
    }

    public function prescription()
    {
        return $this->hasOne(Prescription::class);
    }

    public function rating()
    {
        return $this->hasOne(Rating::class);
    }

    public function coupon()
    {
        return $this->belongsTo(Coupon::class);
    }
}
