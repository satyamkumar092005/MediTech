<?php

namespace App\Http\Controllers;

use App\Models\Specialization;
use Illuminate\Http\Request;
use Inertia\Inertia;

class SpecializationController extends Controller
{
    public function index()
    {
        $specializations = Specialization::all();

        return Inertia::render('Admin/Specializations', [
            'specializations' => $specializations,
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'slug' => 'required|string|unique:specializations,slug',
            'description' => 'nullable|string',
            'icon' => 'nullable|string',
        ]);

        Specialization::create($validated);

        return redirect()->back()->with('success', 'Specialization created.');
    }

    public function update(Request $request, Specialization $specialization)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'slug' => 'required|string|unique:specializations,slug,' . $specialization->id,
            'description' => 'nullable|string',
            'icon' => 'nullable|string',
        ]);

        $specialization->update($validated);

        return redirect()->back()->with('success', 'Specialization updated.');
    }

    public function destroy(Specialization $specialization)
    {
        $specialization->delete();

        return redirect()->back()->with('success', 'Specialization deleted.');
    }
}
