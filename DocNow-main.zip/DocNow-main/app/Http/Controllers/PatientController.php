<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Patient;
use Illuminate\Http\Request;
use Inertia\Inertia;

class PatientController extends Controller
{
    public function index(Request $request)
    {
        $doctor = auth()->user()->doctor;

        $patientIds = Appointment::where('doctor_id', $doctor->id)
            ->distinct()
            ->pluck('patient_id');

        $patients = Patient::with('user')
            ->whereIn('id', $patientIds);

        if ($search = $request->get('search')) {
            $patients->whereHas('user', function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            });
        }

        return Inertia::render('Doctor/Patients', [
            'patients' => $patients->paginate(12),
            'filters' => $request->only('search'),
        ]);
    }
}
