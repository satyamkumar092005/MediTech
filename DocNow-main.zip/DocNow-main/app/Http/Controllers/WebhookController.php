<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

class WebhookController extends Controller
{
    public function razorpay(Request $request)
    {
        $webhookSecret = config('services.razorpay.webhook_secret');
        $webhookSignature = $request->header('X-Razorpay-Signature');

        if (!$webhookSecret || !$webhookSignature) {
            Log::warning('Razorpay Webhook: Missing secret or signature.');
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $api = new Api(config('services.razorpay.key'), config('services.razorpay.secret'));

        try {
            $api->utility->verifyWebhookSignature($request->getContent(), $webhookSignature, $webhookSecret);
        } catch (SignatureVerificationError $e) {
            Log::error('Razorpay Webhook Signature Verification Failed: ' . $e->getMessage());
            return response()->json(['error' => 'Invalid signature'], 400);
        }

        $payload = $request->all();

        if (isset($payload['event']) && $payload['event'] === 'payment.captured') {
            $paymentId = $payload['payload']['payment']['entity']['id'] ?? null;
            $orderId = $payload['payload']['payment']['entity']['order_id'] ?? null;

            if ($orderId && $paymentId) {
                $appointment = Appointment::where('razorpay_order_id', $orderId)->first();
                if ($appointment && $appointment->status === 'pending') {
                    $appointment->update([
                        'status' => 'confirmed',
                        'payment_id' => $paymentId,
                    ]);
                    \App\Events\AppointmentStatusUpdated::dispatch($appointment);
                    Log::info("Appointment {$appointment->id} confirmed via webhook.");
                }
            }
        }

        return response()->json(['status' => 'success']);
    }
}
