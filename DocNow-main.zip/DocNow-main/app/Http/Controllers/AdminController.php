<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use App\Models\Specialization;
use App\Models\User;
use Illuminate\Http\Request;
use Inertia\Inertia;

class AdminController extends Controller
{
    public function dashboard()
    {
        $totalUsers = User::count();
        $totalDoctors = Doctor::count();
        $totalAppointments = \App\Models\Appointment::count();
        $completedAppointments = \App\Models\Appointment::where('status', 'completed')->count();
        
        $revenue = \App\Models\Appointment::whereIn('status', ['confirmed', 'completed'])
            ->join('doctors', 'appointments.doctor_id', '=', 'doctors.id')
            ->sum('doctors.consultation_fee');

        $recentAppointments = \App\Models\Appointment::with(['doctor.user', 'patient.user'])
            ->orderBy('created_at', 'desc')
            ->take(5)
            ->get();

        return Inertia::render('Dashboard/AdminDashboard', [
            'stats' => [
                'totalUsers' => $totalUsers,
                'totalDoctors' => $totalDoctors,
                'totalAppointments' => $totalAppointments,
                'completedAppointments' => $completedAppointments,
                'estimatedRevenue' => $revenue,
            ],
            'recentAppointments' => $recentAppointments,
        ]);
    }

    public function users()
    {
        $users = User::with('roles')->paginate(15);

        return Inertia::render('Admin/Users', [
            'users' => $users,
        ]);
    }

    public function updateUserRole(Request $request, User $user)
    {
        $validated = $request->validate([
            'role' => 'required|string|in:admin,doctor,patient',
        ]);

        $user->syncRoles([$validated['role']]);

        return redirect()->back()->with('success', 'User role updated.');
    }

    public function destroyUser(User $user)
    {
        if ($user->id === auth()->id()) {
            return redirect()->back()->with('error', 'Cannot delete yourself.');
        }

        $user->delete();

        return redirect()->back()->with('success', 'User deleted.');
    }

    public function doctors()
    {
        $doctors = Doctor::with(['user', 'specialization'])->paginate(15);

        return Inertia::render('Admin/Doctors', [
            'doctors' => $doctors,
        ]);
    }

    public function createDoctor()
    {
        $specializations = Specialization::all();

        return Inertia::render('Admin/CreateDoctor', [
            'specializations' => $specializations,
        ]);
    }

    public function storeDoctor(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:8',
            'specialization_id' => 'required|exists:specializations,id',
            'license_number' => 'required|string|unique:doctors,license_number',
            'qualifications' => 'nullable|string',
            'bio' => 'nullable|string',
            'years_of_experience' => 'required|integer|min:0',
            'consultation_fee' => 'required|numeric|min:0',
        ]);

        $femaleNames = [
            'Priya', 'Sneha', 'Ananya', 'Meera', 'Kavita', 'Deepa', 'Pooja',
            'Anjali', 'Sunita', 'Ritu', 'Kiran', 'Sangeeta', 'Anita', 'Maya',
            'Shanti', 'Laxmi', 'Saraswati', 'Parvati', 'Radha', 'Sita'
        ];

        $isFemale = false;
        foreach ($femaleNames as $femaleName) {
            if (stripos($validated['name'], $femaleName) !== false) {
                $isFemale = true;
                break;
            }
        }

        $avatar = "https://randomuser.me/api/portraits/" . ($isFemale ? 'women' : 'men') . "/" . rand(1, 99) . ".jpg";

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => bcrypt($validated['password']),
            'email_verified_at' => now(),
            'gender' => $isFemale ? 'female' : 'male',
            'avatar' => $avatar,
        ]);
        $user->assignRole('doctor');

        Doctor::create([
            'user_id' => $user->id,
            'specialization_id' => $validated['specialization_id'],
            'license_number' => $validated['license_number'],
            'qualifications' => $validated['qualifications'],
            'bio' => $validated['bio'],
            'years_of_experience' => $validated['years_of_experience'],
            'consultation_fee' => $validated['consultation_fee'],
        ]);

        return redirect()->route('admin.doctors')->with('success', 'Doctor created.');
    }

    public function editDoctor(Doctor $doctor)
    {
        $doctor->load('user');
        $specializations = Specialization::all();

        return Inertia::render('Admin/EditDoctor', [
            'doctor' => $doctor,
            'specializations' => $specializations,
        ]);
    }

    public function updateDoctor(Request $request, Doctor $doctor)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $doctor->user_id,
            'specialization_id' => 'required|exists:specializations,id',
            'license_number' => 'required|string|unique:doctors,license_number,' . $doctor->id,
            'qualifications' => 'nullable|string',
            'bio' => 'nullable|string',
            'years_of_experience' => 'required|integer|min:0',
            'consultation_fee' => 'required|numeric|min:0',
        ]);

        $doctor->user->update([
            'name' => $validated['name'],
            'email' => $validated['email'],
        ]);

        $doctor->update([
            'specialization_id' => $validated['specialization_id'],
            'license_number' => $validated['license_number'],
            'qualifications' => $validated['qualifications'],
            'bio' => $validated['bio'],
            'years_of_experience' => $validated['years_of_experience'],
            'consultation_fee' => $validated['consultation_fee'],
        ]);

        return redirect()->route('admin.doctors')->with('success', 'Doctor updated.');
    }

    public function destroyDoctor(Doctor $doctor)
    {
        $doctor->user->delete();
        $doctor->delete();

        return redirect()->back()->with('success', 'Doctor deleted.');
    }
}
