<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use App\Models\Specialization;
use Illuminate\Http\Request;
use Inertia\Inertia;

class DoctorController extends Controller
{
    public function index(Request $request)
    {
        $query = Doctor::with(['user', 'specialization'])
            ->where('is_available', true);

        if ($request->filled('specialization')) {
            $query->where('specialization_id', $request->specialization);
        }

        if ($request->filled('search')) {
            $search = $request->search;
            $query->whereHas('user', function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            });
        }

        $doctors = $query->paginate(12)->through(function ($doctor) {
            $doctor->average_rating = $doctor->ratings()->avg('rating');
            $doctor->review_count = $doctor->ratings()->count();
            return $doctor;
        });

        return Inertia::render('Patient/DoctorsIndex', [
            'doctors' => $doctors,
            'specializations' => Specialization::all(),
            'filters' => $request->only(['specialization', 'search']),
        ]);
    }

    public function show(Doctor $doctor)
    {
        $doctor->load(['user', 'specialization', 'schedules' => function ($q) {
            $q->where('is_active', true);
        }, 'ratings.patient.user']);

        $doctor->average_rating = $doctor->ratings()->avg('rating');
        $doctor->review_count = $doctor->ratings()->count();

        return Inertia::render('Patient/DoctorProfile', [
            'doctor' => $doctor,
        ]);
    }
}
