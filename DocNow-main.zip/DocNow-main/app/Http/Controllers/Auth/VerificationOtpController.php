<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\EmailVerification;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Inertia\Inertia;

class VerificationOtpController extends Controller
{
    public function show(Request $request)
    {
        $email = $request->get('email');

        if (!$email || !User::where('email', $email)->exists()) {
            return redirect()->route('login');
        }

        return Inertia::render('Auth/VerifyOtp', [
            'email' => $email,
        ]);
    }

    public function verify(Request $request)
    {
        $validated = $request->validate([
            'email' => 'required|email|exists:users,email',
            'otp' => 'required|string|size:6',
        ]);

        $user = User::where('email', $validated['email'])->first();

        if ($user->email_verified_at) {
            Auth::login($user);
            return redirect()->intended(route('dashboard', absolute: false));
        }

        $verification = EmailVerification::where('user_id', $user->id)
            ->where('otp', $validated['otp'])
            ->whereNull('used_at')
            ->latest()
            ->first();

        if (!$verification || !$verification->isValid()) {
            return back()->withErrors(['otp' => 'Invalid or expired verification code.']);
        }

        $verification->update(['used_at' => now()]);
        $user->update(['email_verified_at' => now()]);

        if (!$user->hasRole('patient') && !$user->hasRole('doctor') && !$user->hasRole('admin')) {
            $user->patient()->create();
            $user->assignRole('patient');
        }

        Auth::login($user);

        return redirect()->intended(route('dashboard', absolute: false));
    }

    public function resend(Request $request)
    {
        $validated = $request->validate([
            'email' => 'required|email|exists:users,email',
        ]);

        $user = User::where('email', $validated['email'])->first();

        if ($user->email_verified_at) {
            return redirect()->intended(route('dashboard', absolute: false));
        }

        EmailVerification::where('user_id', $user->id)
            ->whereNull('used_at')
            ->update(['used_at' => now()]);

        $otp = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);

        EmailVerification::create([
            'user_id' => $user->id,
            'otp' => $otp,
            'expires_at' => now()->addMinutes(10),
        ]);

        Mail::to($user)->send(new \App\Mail\SendOtpMail($user, $otp));

        return back()->with('success', 'New verification code sent to your email.');
    }
}
