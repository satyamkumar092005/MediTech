<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class GeminiController extends Controller
{
    public function chat(Request $request)
    {
        $validated = $request->validate([
            'message' => 'required|string',
            'doctor_name' => 'required|string',
            'specialization' => 'required|string',
        ]);

        $apiKey = config('services.gemini.api_key');
        if (!$apiKey) {
            return response()->json(['error' => 'Gemini API key not configured.'], 500);
        }

        $prompt = "You are Dr. {$validated['doctor_name']}, a specialist in {$validated['specialization']}. " .
            "Respond to your patient's query in a professional, empathetic, and helpful manner. " .
            "Keep responses concise (max 3 sentences) and suitable for a telemedicine consultation. " .
            "If the issue sounds serious, advise booking an in-person follow-up.\n\n" .
            "Patient: {$validated['message']}\n" .
            "Dr. {$validated['doctor_name']}:";

        $response = Http::post("https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key={$apiKey}", [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt],
                    ],
                ],
            ],
            'generationConfig' => [
                'maxOutputTokens' => 200,
                'temperature' => 0.7,
            ],
        ]);

        if ($response->failed()) {
            return response()->json([
                'error' => 'Failed to get response from AI.',
                'details' => $response->body(),
            ], 500);
        }

        $text = $response->json('candidates.0.content.parts.0.text', 'Sorry, I cannot answer that right now.');

        return response()->json([
            'reply' => $text,
        ]);
    }

    public function symptomCheck(Request $request)
    {
        $validated = $request->validate([
            'symptoms' => 'required|string',
        ]);

        $apiKey = config('services.gemini.api_key');
        if (!$apiKey) {
            return response()->json(['error' => 'Gemini API key not configured.'], 500);
        }

        $prompt = "You are an AI medical assistant for DocNow telemedicine. " .
            "A patient has described their symptoms: '{$validated['symptoms']}'. " .
            "Write a brief (3-4 sentences), professional medical abstract summarizing their condition. " .
            "Suggest what type of specialist they might want to consult. " .
            "Always include a disclaimer that you are an AI and this is not a final diagnosis.";

        $response = Http::post("https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key={$apiKey}", [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt],
                    ],
                ],
            ],
            'generationConfig' => [
                'maxOutputTokens' => 300,
                'temperature' => 0.4,
            ],
        ]);

        if ($response->failed()) {
            return response()->json([
                'error' => 'Failed to get response from AI.',
            ], 500);
        }

        $text = $response->json('candidates.0.content.parts.0.text', 'Sorry, I could not process the symptoms at this time.');

        return response()->json([
            'summary' => $text,
        ]);
    }
}
