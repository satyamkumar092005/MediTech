<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Prescription;
use App\Models\Rating;
use App\Models\Schedule;
use App\Models\Specialization;
use App\Models\User;
use Illuminate\Http\Request;
use Inertia\Inertia;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        if ($user->hasRole('admin')) {
            $completedAppointments = Appointment::where('status', 'completed')->count();
            $revenue = Appointment::whereIn('status', ['confirmed', 'completed'])
                ->join('doctors', 'appointments.doctor_id', '=', 'doctors.id')
                ->sum('doctors.consultation_fee');

            return Inertia::render('Dashboard/AdminDashboard', [
                'stats' => [
                    'totalUsers' => User::count(),
                    'totalDoctors' => Doctor::count(),
                    'totalAppointments' => Appointment::count(),
                    'completedAppointments' => $completedAppointments,
                    'estimatedRevenue' => $revenue,
                ],
                'recentAppointments' => Appointment::with(['doctor.user', 'patient.user'])
                    ->latest()->take(5)->get(),
            ]);
        }

        if ($user->hasRole('doctor')) {
            $doctor = $user->doctor;

            $stats = [
                'todayAppointments' => Appointment::where('doctor_id', $doctor->id)
                    ->whereDate('appointment_date', today())
                    ->count(),
                'totalPatients' => Appointment::where('doctor_id', $doctor->id)
                    ->distinct('patient_id')
                    ->count('patient_id'),
                'averageRating' => Rating::where('doctor_id', $doctor->id)
                    ->avg('rating'),
                'activeSlots' => Schedule::where('doctor_id', $doctor->id)
                    ->where('is_active', true)
                    ->count(),
                'upcomingAppointments' => Appointment::with(['patient.user'])
                    ->where('doctor_id', $doctor->id)
                    ->where('appointment_date', '>=', today())
                    ->whereIn('status', ['pending', 'confirmed'])
                    ->latest('appointment_date')->take(5)->get(),
                'recentPrescriptions' => Prescription::with(['appointment.patient.user'])
                    ->where('doctor_id', $doctor->id)
                    ->latest()->take(5)->get(),
            ];

            return Inertia::render('Dashboard/DoctorDashboard', $stats);
        }

        $patient = $user->patient;

        $stats = [
            'upcomingAppointments' => Appointment::where('patient_id', $patient->id)
                ->where('appointment_date', '>=', today())
                ->whereIn('status', ['pending', 'confirmed'])
                ->count(),
            'totalPrescriptions' => Prescription::where('patient_id', $patient->id)->count(),
            'availableDoctors' => Doctor::count(),
            'myRatings' => Rating::where('patient_id', $patient->id)->count(),
            'recentAppointments' => Appointment::with(['doctor.user', 'doctor.specialization'])
                ->where('patient_id', $patient->id)
                ->latest()->take(5)->get(),
            'recentPrescriptions' => Prescription::with(['doctor.user', 'items'])
                ->where('patient_id', $patient->id)
                ->latest()->take(5)->get(),
        ];

        return Inertia::render('Dashboard/PatientDashboard', $stats);
    }
}
