<?php

namespace App\Http\Controllers;

use App\Mail\PrescriptionCreatedMail;
use App\Models\Appointment;
use App\Models\Prescription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Inertia\Inertia;

class PrescriptionController extends Controller
{
    public function index()
    {
        $patient = auth()->user()->patient;
        $prescriptions = Prescription::with(['doctor.user', 'items'])
            ->where('patient_id', $patient->id)
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return Inertia::render('Patient/Prescriptions', [
            'prescriptions' => $prescriptions,
        ]);
    }

    public function show(Prescription $prescription)
    {
        $prescription->load(['doctor.user', 'patient.user', 'items']);

        return Inertia::render('Patient/PrescriptionDetail', [
            'prescription' => $prescription,
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'appointment_id' => 'required|exists:appointments,id',
            'notes' => 'nullable|string',
            'follow_up_date' => 'nullable|date',
            'items' => 'required|array|min:1',
            'items.*.medicine_name' => 'required|string',
            'items.*.dosage' => 'required|string',
            'items.*.frequency' => 'required|string',
            'items.*.duration' => 'required|string',
            'items.*.instructions' => 'nullable|string',
        ]);

        $appointment = Appointment::findOrFail($validated['appointment_id']);
        $doctor = auth()->user()->doctor;

        $prescription = Prescription::create([
            'appointment_id' => $appointment->id,
            'doctor_id' => $doctor->id,
            'patient_id' => $appointment->patient_id,
            'notes' => $request->input('notes'),
            'follow_up_date' => $request->input('follow_up_date'),
        ]);

        foreach ($validated['items'] as $item) {
            $prescription->items()->create($item);
        }

        Mail::to($prescription->patient->user)->send(new PrescriptionCreatedMail($prescription));

        return redirect()->back()->with('success', 'Prescription created.');
    }

    public function toggleFill(Prescription $prescription)
    {
        $prescription->update([
            'is_filled' => !$prescription->is_filled,
        ]);

        return redirect()->back()->with('success', 'Prescription status updated.');
    }
}
