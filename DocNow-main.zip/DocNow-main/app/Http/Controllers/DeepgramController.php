<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class DeepgramController extends Controller
{
    public function token()
    {
        $apiKey = config('services.deepgram.api_key');
        if (!$apiKey) {
            return response()->json(['error' => 'Deepgram API key not configured.'], 500);
        }

        $response = Http::withHeaders(['Authorization' => 'Token ' . $apiKey])
            ->post('https://api.deepgram.com/v1/auth/grant', [
                'ttl' => 30,
            ]);

        if ($response->failed()) {
            return response()->json(['error' => 'Failed to generate token.'], 500);
        }

        return response($response->json('access_token'));
    }

    public function settings(Request $request, Appointment $appointment)
    {
        $appointment->load(['doctor.user', 'doctor.specialization']);

        $doctorName = str_replace('Dr. ', '', $appointment->doctor->user->name);
        $specialization = $appointment->doctor->specialization->name;

        return response()->json([
            'type' => 'Settings',
            'audio' => [
                'input' => [
                    'encoding' => 'linear16',
                    'sample_rate' => 16000,
                ],
                'output' => [
                    'encoding' => 'linear16',
                    'sample_rate' => 24000,
                    'container' => 'none',
                ],
            ],
            'agent' => [
                'listen' => [
                    'provider' => [
                        'type' => 'deepgram',
                        'model' => 'nova-3',
                    ],
                ],
                'think' => [
                    'provider' => [
                        'type' => 'google',
                        'model' => 'gemini-3-flash-preview',
                        'temperature' => 0.7,
                    ],
                    'prompt' => "You are Dr. {$doctorName}, a specialist in {$specialization}. " .
                        "During consultations, always suggest appropriate medications, health checkups, or lifestyle changes based on the patient's symptoms. " .
                        "Start by greeting the patient warmly and asking how you can help. " .
                        "Respond conversationally and empathetically in 2-3 sentences. " .
                        "At the end of the conversation, provide a brief treatment plan with medication recommendations or recommended checkups. " .
                        "If symptoms sound serious, advise seeing a specialist in person. " .
                        "Always listen to the patient fully before responding. Keep responses natural for spoken conversation.",
                ],
                'speak' => [
                    'provider' => [
                        'type' => 'deepgram',
                        'model' => 'aura-2-thalia-en',
                    ],
                ],
                'greeting' => "Hello! I'm Dr. {$doctorName}. Welcome to your live consultation. How can I help you today?",
            ],
        ]);
    }
}
