<?php

namespace App\Http\Controllers;

use App\Models\Coupon;
use Illuminate\Http\Request;

class CouponController extends Controller
{
    public function validateCoupon(Request $request)
    {
        $request->validate([
            'code' => 'required|string',
            'amount' => 'required|numeric|min:0',
        ]);

        $coupon = Coupon::where('code', strtoupper($request->code))->first();

        if (!$coupon || !$coupon->isValid()) {
            return response()->json(['error' => 'Invalid or expired coupon code.'], 422);
        }

        $discount = 0;
        if ($coupon->discount_type === 'percentage') {
            $discount = ($request->amount * $coupon->value) / 100;
        } else {
            $discount = $coupon->value;
        }

        // Cap discount at total amount
        $discount = min($discount, $request->amount);
        $newAmount = max(0, $request->amount - $discount);

        return response()->json([
            'coupon_id' => $coupon->id,
            'code' => $coupon->code,
            'discount' => round($discount, 2),
            'new_amount' => round($newAmount, 2),
        ]);
    }
}
