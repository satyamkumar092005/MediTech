<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Rating;
use Illuminate\Http\Request;
use Inertia\Inertia;

class RatingController extends Controller
{
    public function create(Appointment $appointment)
    {
        $appointment->load(['doctor.user', 'doctor.specialization']);

        if ($appointment->patient_id !== auth()->user()->patient->id) {
            abort(403);
        }

        if ($appointment->status !== 'completed') {
            return redirect()->route('patient.appointments.show', $appointment)
                ->with('error', 'Can only rate completed appointments.');
        }

        if ($appointment->rating) {
            return redirect()->route('patient.appointments.show', $appointment)
                ->with('error', 'Already rated this appointment.');
        }

        return Inertia::render('Patient/RateDoctor', [
            'appointment' => $appointment,
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'appointment_id' => 'required|exists:appointments,id',
            'rating' => 'required|integer|min:1|max:5',
            'review' => 'nullable|string|max:1000',
        ]);

        $appointment = Appointment::findOrFail($validated['appointment_id']);

        if ($appointment->patient_id !== auth()->user()->patient->id) {
            abort(403);
        }

        if ($appointment->status !== 'completed') {
            return back()->withErrors(['error' => 'Can only rate completed appointments.']);
        }

        Rating::create([
            'appointment_id' => $appointment->id,
            'doctor_id' => $appointment->doctor_id,
            'patient_id' => $appointment->patient_id,
            'rating' => $validated['rating'],
            'review' => $request->input('review'),
        ]);

        return redirect()->route('patient.appointments.show', $appointment)
            ->with('success', 'Rating submitted.');
    }

    public function doctorIndex()
    {
        $doctor = auth()->user()->doctor;
        $ratings = Rating::with(['patient.user', 'appointment'])
            ->where('doctor_id', $doctor->id)
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return Inertia::render('Doctor/Ratings', [
            'ratings' => $ratings,
        ]);
    }
}
