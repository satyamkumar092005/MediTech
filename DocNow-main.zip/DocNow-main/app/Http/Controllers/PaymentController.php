<?php

namespace App\Http\Controllers;

use Razorpay\Api\Api;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    private Api $api;

    public function __construct()
    {
        $this->api = new Api(
            config('services.razorpay.key'),
            config('services.razorpay.secret')
        );
    }

    public function createOrder(Request $request)
    {
        $validated = $request->validate([
            'amount' => 'required|numeric|min:1',
            'doctor_id' => 'required|exists:doctors,id',
        ]);

        $order = $this->api->order->create([
            'amount' => (int) ($validated['amount'] * 100),
            'currency' => 'INR',
            'receipt' => 'doc_' . uniqid(),
            'notes' => [
                'doctor_id' => $validated['doctor_id'],
                'patient_id' => auth()->user()->patient->id,
            ],
        ]);

        return response()->json([
            'order_id' => $order->id,
            'amount' => $order->amount,
            'currency' => $order->currency,
            'key' => config('services.razorpay.key'),
        ]);
    }

    public function verifyPayment(Request $request)
    {
        $validated = $request->validate([
            'razorpay_payment_id' => 'required|string',
            'razorpay_order_id' => 'required|string',
            'razorpay_signature' => 'required|string',
        ]);

        $attributes = [
            'razorpay_order_id' => $validated['razorpay_order_id'],
            'razorpay_payment_id' => $validated['razorpay_payment_id'],
            'razorpay_signature' => $validated['razorpay_signature'],
        ];

        try {
            $this->api->utility->verifyPaymentSignature($attributes);

            return response()->json([
                'success' => true,
                'payment_id' => $validated['razorpay_payment_id'],
                'order_id' => $validated['razorpay_order_id'],
            ]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Payment verification failed.'], 422);
        }
    }
}
