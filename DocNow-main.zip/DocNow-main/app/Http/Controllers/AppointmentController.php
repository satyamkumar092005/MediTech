<?php

namespace App\Http\Controllers;

use App\Mail\AppointmentBookedMail;
use App\Mail\AppointmentCancelledMail;
use App\Mail\AppointmentConfirmedMail;
use App\Models\Appointment;
use App\Models\Coupon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Inertia\Inertia;
use Razorpay\Api\Api;

class AppointmentController extends Controller
{
    private Api $razorpay;

    public function __construct()
    {
        $this->razorpay = new Api(
            config('services.razorpay.key'),
            config('services.razorpay.secret')
        );
    }

    public function index()
    {
        $patient = auth()->user()->patient;
        $appointments = Appointment::with(['doctor.user', 'doctor.specialization', 'prescription'])
            ->where('patient_id', $patient->id)
            ->orderBy('appointment_date', 'desc')
            ->paginate(10);

        return Inertia::render('Patient/Appointments', [
            'appointments' => $appointments,
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'doctor_id' => 'required|exists:doctors,id',
            'appointment_date' => 'required|date|after_or_equal:today',
            'start_time' => 'required',
            'end_time' => 'required',
            'type' => 'required|in:virtual',
            'notes' => 'nullable|string|max:500',
            'payment_id' => 'required|string',
            'razorpay_order_id' => 'nullable|string',
            'razorpay_signature' => 'nullable|string',
            'coupon_id' => 'nullable|exists:coupons,id',
            'is_free' => 'boolean',
        ]);

        if (empty($validated['is_free'])) {
            // Verify Razorpay signature
            try {
                $this->razorpay->utility->verifyPaymentSignature([
                    'razorpay_order_id' => $validated['razorpay_order_id'],
                    'razorpay_payment_id' => $validated['payment_id'],
                    'razorpay_signature' => $validated['razorpay_signature'],
                ]);
            } catch (\Exception $e) {
                return redirect()->back()->withErrors(['payment' => 'Payment verification failed.']);
            }
        }

        if (!empty($validated['coupon_id'])) {
            Coupon::where('id', $validated['coupon_id'])->increment('used_count');
        }

        $patient = auth()->user()->patient;

        $appointment = Appointment::create([
            'doctor_id' => $validated['doctor_id'],
            'patient_id' => $patient->id,
            'appointment_date' => $validated['appointment_date'],
            'start_time' => $validated['start_time'],
            'end_time' => $validated['end_time'],
            'type' => $validated['type'],
            'notes' => $request->input('notes'),
            'payment_id' => $validated['payment_id'],
            'razorpay_order_id' => $request->input('razorpay_order_id'),
            'razorpay_signature' => $request->input('razorpay_signature'),
            'coupon_id' => $request->input('coupon_id'),
            'status' => 'pending',
        ]);

        Mail::to($appointment->patient->user)->send(new AppointmentBookedMail($appointment));

        return redirect()->route('patient.appointments.show', $appointment)
            ->with('success', 'Appointment booked successfully.');
    }

    public function instant(Request $request)
    {
        $validated = $request->validate([
            'doctor_id' => 'required|exists:doctors,id',
            'payment_id' => 'required|string',
            'razorpay_order_id' => 'nullable|string',
            'razorpay_signature' => 'nullable|string',
            'coupon_id' => 'nullable|exists:coupons,id',
            'is_free' => 'boolean',
        ]);

        if (empty($validated['is_free'])) {
            // Verify Razorpay signature
            try {
                $this->razorpay->utility->verifyPaymentSignature([
                    'razorpay_order_id' => $validated['razorpay_order_id'],
                    'razorpay_payment_id' => $validated['payment_id'],
                    'razorpay_signature' => $validated['razorpay_signature'],
                ]);
            } catch (\Exception $e) {
                return redirect()->back()->withErrors(['payment' => 'Payment verification failed.']);
            }
        }

        if (!empty($validated['coupon_id'])) {
            Coupon::where('id', $validated['coupon_id'])->increment('used_count');
        }

        $patient = auth()->user()->patient;
        $now = now();

        $appointment = Appointment::create([
            'doctor_id' => $validated['doctor_id'],
            'patient_id' => $patient->id,
            'appointment_date' => $now->format('Y-m-d'),
            'start_time' => $now->format('H:i'),
            'end_time' => $now->addHour()->format('H:i'),
            'type' => 'virtual',
            'payment_id' => $validated['payment_id'],
            'razorpay_order_id' => $request->input('razorpay_order_id'),
            'razorpay_signature' => $request->input('razorpay_signature'),
            'coupon_id' => $request->input('coupon_id'),
            'status' => 'confirmed',
        ]);

        Mail::to($appointment->patient->user)->send(new AppointmentBookedMail($appointment));

        return redirect()->route('patient.appointments.call', $appointment)
            ->with('success', 'Instant consultation started.');
    }

    public function show(Appointment $appointment)
    {
        $appointment->load(['doctor.user', 'doctor.specialization', 'prescription.items', 'rating']);

        return Inertia::render('Patient/AppointmentDetail', [
            'appointment' => $appointment,
        ]);
    }

    public function cancel(Appointment $appointment)
    {
        if ($appointment->patient_id !== auth()->user()->patient->id) {
            abort(403);
        }

        $appointment->update(['status' => 'cancelled']);

        Mail::to($appointment->patient->user)->send(new AppointmentCancelledMail($appointment));

        return redirect()->back()->with('success', 'Appointment cancelled.');
    }

    public function doctorIndex()
    {
        $doctor = auth()->user()->doctor;
        $appointments = Appointment::with(['patient.user', 'prescription'])
            ->where('doctor_id', $doctor->id)
            ->orderBy('appointment_date', 'desc')
            ->paginate(10);

        return Inertia::render('Doctor/Appointments', [
            'appointments' => $appointments,
        ]);
    }

    public function doctorShow(Appointment $appointment)
    {
        $appointment->load(['patient.user', 'prescription.items']);

        return Inertia::render('Doctor/AppointmentDetail', [
            'appointment' => $appointment,
        ]);
    }

    public function complete(Appointment $appointment)
    {
        if ($appointment->doctor_id !== auth()->user()->doctor->id) {
            abort(403);
        }

        $appointment->update(['status' => 'completed']);
        \App\Events\AppointmentStatusUpdated::dispatch($appointment);

        return redirect()->back()->with('success', 'Appointment completed.');
    }

    public function confirm(Appointment $appointment)
    {
        if ($appointment->doctor_id !== auth()->user()->doctor->id) {
            abort(403);
        }

        $appointment->update(['status' => 'confirmed']);

        Mail::to($appointment->patient->user)->send(new AppointmentConfirmedMail($appointment));
        \App\Events\AppointmentStatusUpdated::dispatch($appointment);

        return redirect()->back()->with('success', 'Appointment confirmed.');
    }

    public function call(Appointment $appointment)
    {
        if ($appointment->patient_id !== auth()->user()->patient->id) {
            abort(403);
        }

        $appointment->load(['doctor.user', 'doctor.specialization']);

        return Inertia::render('Patient/VideoCall', [
            'appointment' => $appointment,
        ]);
    }

    public function saveSummary(Request $request, Appointment $appointment)
    {
        $request->validate([
            'transcript' => 'required|string',
        ]);

        $appointment->update([
            'consultation_summary' => $request->transcript,
        ]);

        return response()->json(['success' => true]);
    }

    public function adminIndex()
    {
        $appointments = Appointment::with(['doctor.user', 'patient.user'])
            ->orderBy('appointment_date', 'desc')
            ->paginate(15);

        return Inertia::render('Admin/Appointments', [
            'appointments' => $appointments,
        ]);
    }
}
