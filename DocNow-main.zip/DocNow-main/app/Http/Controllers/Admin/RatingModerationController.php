<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Rating;
use Inertia\Inertia;

class RatingModerationController extends Controller
{
    public function index()
    {
        $ratings = Rating::with(['patient.user', 'doctor.user', 'appointment'])
            ->orderBy('created_at', 'desc')
            ->paginate(15);

        return Inertia::render('Admin/Ratings', [
            'ratings' => $ratings,
        ]);
    }

    public function approve(Rating $rating)
    {
        $rating->update(['is_approved' => !$rating->is_approved]);

        return redirect()->back()->with('success', 'Rating status updated.');
    }

    public function destroy(Rating $rating)
    {
        $rating->delete();

        return redirect()->back()->with('success', 'Rating deleted.');
    }
}
