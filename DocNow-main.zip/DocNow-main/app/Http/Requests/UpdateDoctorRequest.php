<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateDoctorRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $doctorId = $this->route('doctor')->id;

        return [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $this->route('doctor')->user_id,
            'specialization_id' => 'required|exists:specializations,id',
            'license_number' => 'required|string|unique:doctors,license_number,' . $doctorId,
            'qualifications' => 'nullable|string',
            'bio' => 'nullable|string',
            'years_of_experience' => 'required|integer|min:0',
            'consultation_fee' => 'required|numeric|min:0',
        ];
    }
}
