<?php

namespace App\Mail;

use App\Models\Appointment;
use App\Services\CalendarService;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Attachment;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class AppointmentBookedMail extends Mailable
{
    use Queueable, SerializesModels;

    public Appointment $appointment;

    public function __construct(Appointment $appointment)
    {
        $this->appointment = $appointment;
    }

    public function envelope(): Envelope
    {
        return new Envelope(subject: 'Appointment Booked Successfully');
    }

    public function content(): Content
    {
        return new Content(view: 'emails.appointment-booked');
    }

    public function attachments(): array
    {
        $calendarService = new CalendarService();
        $icsContent = $calendarService->generateIcs($this->appointment);

        return [
            Attachment::fromData(fn () => $icsContent, 'invite.ics')
                ->withMime('text/calendar'),
        ];
    }
}
