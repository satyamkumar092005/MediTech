<?php

namespace App\Mail;

use App\Models\Prescription;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class PrescriptionCreatedMail extends Mailable
{
    use Queueable, SerializesModels;

    public Prescription $prescription;

    public function __construct(Prescription $prescription)
    {
        $this->prescription = $prescription;
    }

    public function envelope(): Envelope
    {
        return new Envelope(subject: 'Prescription Available');
    }

    public function content(): Content
    {
        return new Content(view: 'emails.prescription-created');
    }
}
