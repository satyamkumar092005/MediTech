<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AppointmentController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DoctorController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\PrescriptionController;
use App\Http\Controllers\RatingController;
use App\Http\Controllers\ScheduleController;
use App\Http\Controllers\SpecializationController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\Admin\RatingModerationController;
use App\Http\Controllers\WebhookController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::post('/webhooks/razorpay', [WebhookController::class, 'razorpay'])->name('webhooks.razorpay');

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::middleware('role:patient')->prefix('patient')->name('patient.')->group(function () {
        Route::get('/doctors', [DoctorController::class, 'index'])->name('doctors.index');
        Route::get('/doctors/{doctor}', [DoctorController::class, 'show'])->name('doctors.show');
        Route::get('/appointments', [AppointmentController::class, 'index'])->name('appointments.index');
        Route::post('/appointments', [AppointmentController::class, 'store'])->name('appointments.store');
        Route::post('/appointments/instant', [AppointmentController::class, 'instant'])->name('appointments.instant');
        Route::get('/appointments/{appointment}', [AppointmentController::class, 'show'])->name('appointments.show');
        Route::patch('/appointments/{appointment}/cancel', [AppointmentController::class, 'cancel'])->name('appointments.cancel');
        Route::get('/prescriptions', [PrescriptionController::class, 'index'])->name('prescriptions.index');
        Route::get('/prescriptions/{prescription}', [PrescriptionController::class, 'show'])->name('prescriptions.show');
        Route::patch('/prescriptions/{prescription}/fill', [PrescriptionController::class, 'toggleFill'])->name('prescriptions.fill');
        Route::get('/appointments/{appointment}/rate', [RatingController::class, 'create'])->name('ratings.create');
        Route::post('/ratings', [RatingController::class, 'store'])->name('ratings.store');
        Route::get('/appointments/{appointment}/call', [AppointmentController::class, 'call'])->name('appointments.call');
        Route::post('/appointments/{appointment}/summary', [AppointmentController::class, 'saveSummary'])->name('appointments.summary');
        Route::post('/payment/create-order', [PaymentController::class, 'createOrder'])->name('payment.create-order');
        Route::post('/payment/verify', [PaymentController::class, 'verifyPayment'])->name('payment.verify');
        Route::post('/coupons/validate', [\App\Http\Controllers\CouponController::class, 'validateCoupon'])->name('coupons.validate');
        Route::post('/gemini/chat', [\App\Http\Controllers\GeminiController::class, 'chat'])->name('gemini.chat');
        Route::post('/gemini/symptom-check', [\App\Http\Controllers\GeminiController::class, 'symptomCheck'])->name('gemini.symptom-check');
        Route::post('/deepgram/token', [\App\Http\Controllers\DeepgramController::class, 'token'])->name('deepgram.token');
        Route::get('/deepgram/settings/{appointment}', [\App\Http\Controllers\DeepgramController::class, 'settings'])->name('deepgram.settings');
    });

    Route::middleware('role:doctor')->prefix('doctor')->name('doctor.')->group(function () {
        Route::get('/schedule', [ScheduleController::class, 'index'])->name('schedule.index');
        Route::post('/schedule', [ScheduleController::class, 'store'])->name('schedule.store');
        Route::delete('/schedule/{schedule}', [ScheduleController::class, 'destroy'])->name('schedule.destroy');
        Route::get('/appointments', [AppointmentController::class, 'doctorIndex'])->name('appointments.index');
        Route::get('/appointments/{appointment}', [AppointmentController::class, 'doctorShow'])->name('appointments.show');
        Route::patch('/appointments/{appointment}/confirm', [AppointmentController::class, 'confirm'])->name('appointments.confirm');
        Route::patch('/appointments/{appointment}/complete', [AppointmentController::class, 'complete'])->name('appointments.complete');
        Route::post('/prescriptions', [PrescriptionController::class, 'store'])->name('prescriptions.store');
        Route::get('/patients', [PatientController::class, 'index'])->name('patients.index');
        Route::get('/ratings', [RatingController::class, 'doctorIndex'])->name('ratings.index');
    });

    Route::middleware('role:admin')->prefix('admin')->name('admin.')->group(function () {
        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
        Route::get('/users', [AdminController::class, 'users'])->name('users');
        Route::patch('/users/{user}/role', [AdminController::class, 'updateUserRole'])->name('users.role');
        Route::delete('/users/{user}', [AdminController::class, 'destroyUser'])->name('users.destroy');
        Route::get('/doctors', [AdminController::class, 'doctors'])->name('doctors');
        Route::post('/doctors', [AdminController::class, 'storeDoctor'])->name('doctors.store');
        Route::get('/doctors/create', [AdminController::class, 'createDoctor'])->name('doctors.create');
        Route::get('/doctors/{doctor}/edit', [AdminController::class, 'editDoctor'])->name('doctors.edit');
        Route::put('/doctors/{doctor}', [AdminController::class, 'updateDoctor'])->name('doctors.update');
        Route::delete('/doctors/{doctor}', [AdminController::class, 'destroyDoctor'])->name('doctors.destroy');
        Route::get('/specializations', [SpecializationController::class, 'index'])->name('specializations');
        Route::post('/specializations', [SpecializationController::class, 'store'])->name('specializations.store');
        Route::put('/specializations/{specialization}', [SpecializationController::class, 'update'])->name('specializations.update');
        Route::delete('/specializations/{specialization}', [SpecializationController::class, 'destroy'])->name('specializations.destroy');
        Route::get('/appointments', [AppointmentController::class, 'adminIndex'])->name('appointments');
        Route::get('/ratings', [RatingModerationController::class, 'index'])->name('ratings');
        Route::patch('/ratings/{rating}/approve', [RatingModerationController::class, 'approve'])->name('ratings.approve');
        Route::delete('/ratings/{rating}', [RatingModerationController::class, 'destroy'])->name('ratings.destroy');
    });
});

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
