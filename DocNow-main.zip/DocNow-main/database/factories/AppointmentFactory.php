<?php

namespace Database\Factories;

use App\Models\Doctor;
use App\Models\Patient;
use Illuminate\Database\Eloquent\Factories\Factory;

class AppointmentFactory extends Factory
{
    protected $model = \App\Models\Appointment::class;

    public function definition(): array
    {
        return [
            'doctor_id' => Doctor::factory(),
            'patient_id' => Patient::factory(),
            'appointment_date' => fake()->dateTimeBetween('+1 day', '+1 month')->format('Y-m-d'),
            'start_time' => fake()->randomElement(['09:00', '10:00', '11:00', '14:00', '15:00']),
            'end_time' => fake()->randomElement(['09:30', '10:30', '11:30', '14:30', '15:30']),
            'type' => 'virtual',
            'status' => 'pending',
            'notes' => fake()->optional()->sentence(),
        ];
    }
}
