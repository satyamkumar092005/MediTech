<?php

namespace Database\Factories;

use App\Models\Specialization;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class DoctorFactory extends Factory
{
    protected $model = \App\Models\Doctor::class;

    public function definition(): array
    {
        return [
            'user_id' => User::factory(),
            'specialization_id' => Specialization::factory(),
            'license_number' => 'LIC-' . fake()->unique()->randomNumber(5),
            'qualifications' => fake()->sentence(),
            'bio' => fake()->paragraph(),
            'years_of_experience' => fake()->numberBetween(5, 30),
            'consultation_fee' => 10.00,
            'is_available' => true,
        ];
    }
}
