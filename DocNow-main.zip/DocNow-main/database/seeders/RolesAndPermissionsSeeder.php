<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RolesAndPermissionsSeeder extends Seeder
{
    public function run(): void
    {
        app()->make(\Spatie\Permission\PermissionRegistrar::class)->forgetCachedPermissions();

        $permissions = [
            'manage-users',
            'manage-doctors',
            'manage-specializations',
            'manage-all-appointments',
            'book-appointments',
            'cancel-appointments',
            'write-prescriptions',
            'view-prescriptions',
            'rate-doctors',
            'manage-schedule',
            'view-own-appointments',
        ];

        foreach ($permissions as $permission) {
            Permission::create(['name' => $permission]);
        }

        $admin = Role::create(['name' => 'admin']);
        $admin->givePermissionTo(Permission::all());

        $doctor = Role::create(['name' => 'doctor']);
        $doctor->givePermissionTo([
            'view-own-appointments',
            'write-prescriptions',
            'manage-schedule',
            'view-prescriptions',
        ]);

        $patient = Role::create(['name' => 'patient']);
        $patient->givePermissionTo([
            'book-appointments',
            'cancel-appointments',
            'view-own-appointments',
            'view-prescriptions',
            'rate-doctors',
        ]);

        $adminUser = User::factory()->create([
            'name' => 'Admin',
            'email' => 'admin@docnow.com',
            'password' => bcrypt('password'),
        ]);
        $adminUser->assignRole('admin');
    }
}
