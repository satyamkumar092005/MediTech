<?php

namespace Database\Seeders;

use App\Models\Doctor;
use App\Models\Patient;
use App\Models\Schedule;
use App\Models\Specialization;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call(RolesAndPermissionsSeeder::class);

        $specializations = [
            ['name' => 'Cardiology', 'slug' => 'cardiology', 'description' => 'Heart and cardiovascular system'],
            ['name' => 'Dermatology', 'slug' => 'dermatology', 'description' => 'Skin, hair, and nails'],
            ['name' => 'Pediatrics', 'slug' => 'pediatrics', 'description' => 'Children\'s health'],
            ['name' => 'Orthopedics', 'slug' => 'orthopedics', 'description' => 'Bones, joints, and muscles'],
            ['name' => 'Neurology', 'slug' => 'neurology', 'description' => 'Brain and nervous system'],
            ['name' => 'Ophthalmology', 'slug' => 'ophthalmology', 'description' => 'Eye care'],
            ['name' => 'Psychiatry', 'slug' => 'psychiatry', 'description' => 'Mental health'],
            ['name' => 'General Medicine', 'slug' => 'general-medicine', 'description' => 'General health and wellness'],
            ['name' => 'Gynecology', 'slug' => 'gynecology', 'description' => 'Women\'s health'],
            ['name' => 'ENT', 'slug' => 'ent', 'description' => 'Ear, nose, and throat'],
            ['name' => 'Gastroenterology', 'slug' => 'gastroenterology', 'description' => 'Digestive system'],
            ['name' => 'Pulmonology', 'slug' => 'pulmonology', 'description' => 'Respiratory system'],
        ];

        foreach ($specializations as $spec) {
            Specialization::create($spec);
        }

        $doctors = [
            ['name' => 'Dr. Arjun Sharma', 'email' => 'arjun.sharma@docnow.com', 'spec' => 1, 'lic' => 'LIC-001', 'qual' => 'MD, DM Cardiology', 'bio' => 'Senior cardiologist specializing in interventional cardiology and heart failure management.', 'exp' => 18, 'fee' => 10, 'avatar' => 'https://randomuser.me/api/portraits/men/1.jpg'],
            ['name' => 'Dr. Priya Patel', 'email' => 'priya.patel@docnow.com', 'spec' => 2, 'lic' => 'LIC-002', 'qual' => 'MD, DVD', 'bio' => 'Expert dermatologist with focus on cosmetic dermatology and skin cancer screening.', 'exp' => 12, 'fee' => 10, 'avatar' => 'https://randomuser.me/api/portraits/women/1.jpg'],
            ['name' => 'Dr. Vikram Singh', 'email' => 'vikram.singh@docnow.com', 'spec' => 3, 'lic' => 'LIC-003', 'qual' => 'MD Pediatrics', 'bio' => 'Child specialist with expertise in neonatal care and adolescent medicine.', 'exp' => 14, 'fee' => 10, 'avatar' => 'https://randomuser.me/api/portraits/men/2.jpg'],
            ['name' => 'Dr. Sneha Reddy', 'email' => 'sneha.reddy@docnow.com', 'spec' => 4, 'lic' => 'LIC-004', 'qual' => 'MS Orthopedics, DNB', 'bio' => 'Orthopedic surgeon specializing in joint replacement and sports injuries.', 'exp' => 16, 'fee' => 10, 'avatar' => 'https://randomuser.me/api/portraits/women/2.jpg'],
            ['name' => 'Dr. Rajesh Kumar', 'email' => 'rajesh.kumar@docnow.com', 'spec' => 5, 'lic' => 'LIC-005', 'qual' => 'MD, DM Neurology', 'bio' => 'Neurologist with expertise in stroke management, epilepsy, and movement disorders.', 'exp' => 20, 'fee' => 10, 'avatar' => 'https://randomuser.me/api/portraits/men/3.jpg'],
            ['name' => 'Dr. Ananya Gupta', 'email' => 'ananya.gupta@docnow.com', 'spec' => 6, 'lic' => 'LIC-006', 'qual' => 'MS Ophthalmology', 'bio' => 'Eye surgeon specializing in cataract surgery and LASIK procedures.', 'exp' => 11, 'fee' => 10, 'avatar' => 'https://randomuser.me/api/portraits/women/3.jpg'],
            ['name' => 'Dr. Rohan Deshmukh', 'email' => 'rohan.deshmukh@docnow.com', 'spec' => 7, 'lic' => 'LIC-007', 'qual' => 'MD Psychiatry', 'bio' => 'Consultant psychiatrist offering therapy for anxiety, depression, and stress management.', 'exp' => 9, 'fee' => 10, 'avatar' => 'https://randomuser.me/api/portraits/men/4.jpg'],
            ['name' => 'Dr. Meera Iyer', 'email' => 'meera.iyer@docnow.com', 'spec' => 8, 'lic' => 'LIC-008', 'qual' => 'MBBS, MD Medicine', 'bio' => 'General physician providing comprehensive primary care and preventive health checkups.', 'exp' => 7, 'fee' => 10, 'avatar' => 'https://randomuser.me/api/portraits/women/4.jpg'],
            ['name' => 'Dr. Kavita Joshi', 'email' => 'kavita.joshi@docnow.com', 'spec' => 9, 'lic' => 'LIC-009', 'qual' => 'MS, DNB Obstetrics & Gynecology', 'bio' => 'Gynecologist with specialization in high-risk pregnancies and minimally invasive surgery.', 'exp' => 15, 'fee' => 10, 'avatar' => 'https://randomuser.me/api/portraits/women/5.jpg'],
            ['name' => 'Dr. Suresh Nair', 'email' => 'suresh.nair@docnow.com', 'spec' => 10, 'lic' => 'LIC-010', 'qual' => 'MS ENT', 'bio' => 'ENT specialist treating hearing loss, sinus issues, and throat disorders.', 'exp' => 13, 'fee' => 10, 'avatar' => 'https://randomuser.me/api/portraits/men/5.jpg'],
            ['name' => 'Dr. Deepa Menon', 'email' => 'deepa.menon@docnow.com', 'spec' => 11, 'lic' => 'LIC-011', 'qual' => 'MD, DM Gastroenterology', 'bio' => 'Gastroenterologist specializing in liver diseases, IBS, and endoscopy.', 'exp' => 10, 'fee' => 10, 'avatar' => 'https://randomuser.me/api/portraits/women/6.jpg'],
            ['name' => 'Dr. Amit Verma', 'email' => 'amit.verma@docnow.com', 'spec' => 12, 'lic' => 'LIC-012', 'qual' => 'MD, DM Pulmonology', 'bio' => 'Pulmonologist with expertise in asthma, COPD, and sleep disorders.', 'exp' => 14, 'fee' => 10, 'avatar' => 'https://randomuser.me/api/portraits/men/6.jpg'],
            ['name' => 'Dr. Pooja Agarwal', 'email' => 'pooja.agarwal@docnow.com', 'spec' => 2, 'lic' => 'LIC-013', 'qual' => 'MD Dermatology', 'bio' => 'Dermatologist specializing in pediatric dermatology and laser treatments.', 'exp' => 8, 'fee' => 10, 'avatar' => 'https://randomuser.me/api/portraits/women/7.jpg'],
            ['name' => 'Dr. Manoj Tiwari', 'email' => 'manoj.tiwari@docnow.com', 'spec' => 4, 'lic' => 'LIC-014', 'qual' => 'MS Orthopedics', 'bio' => 'Orthopedic surgeon focused on spine surgery and trauma care.', 'exp' => 17, 'fee' => 10, 'avatar' => 'https://randomuser.me/api/portraits/men/7.jpg'],
        ];

        $doctorIds = [];
        foreach ($doctors as $i => $doc) {
            $user = User::factory()->create([
                'name' => $doc['name'],
                'email' => $doc['email'],
                'password' => bcrypt('password'),
                'avatar' => $doc['avatar'],
            ]);
            $user->assignRole('doctor');

            $doctor = Doctor::create([
                'user_id' => $user->id,
                'specialization_id' => $doc['spec'],
                'license_number' => $doc['lic'],
                'qualifications' => $doc['qual'],
                'bio' => $doc['bio'],
                'years_of_experience' => $doc['exp'],
                'consultation_fee' => $doc['fee'],
                'is_available' => true,
            ]);

            $doctorIds[] = $doctor->id;
        }

        $timeSlots = [
            0 => [['09:00', '13:00', 30], ['14:00', '17:00', 30]],
            1 => [['09:00', '13:00', 30], ['14:00', '17:00', 30]],
            2 => [['09:00', '13:00', 30], ['14:00', '17:00', 30]],
            3 => [['09:00', '13:00', 30], ['14:00', '17:00', 30]],
            4 => [['09:00', '13:00', 30], ['14:00', '17:00', 30]],
            5 => [['09:00', '14:00', 45]],
        ];

        foreach ($doctorIds as $docId) {
            foreach ($timeSlots as $day => $slots) {
                foreach ($slots as $slot) {
                    Schedule::create([
                        'doctor_id' => $docId,
                        'day_of_week' => $day,
                        'start_time' => $slot[0],
                        'end_time' => $slot[1],
                        'slot_duration_minutes' => $slot[2],
                        'is_active' => true,
                    ]);
                }
            }
        }

        $patientUser = User::factory()->create([
            'name' => 'Rahul Verma',
            'email' => 'patient@docnow.com',
            'password' => bcrypt('password'),
        ]);
        $patientUser->assignRole('patient');

        Patient::create([
            'user_id' => $patientUser->id,
            'blood_group' => 'B+',
            'allergies' => 'Penicillin, Sulfa',
            'emergency_contact' => '+91-9876543210',
        ]);
    }
}
