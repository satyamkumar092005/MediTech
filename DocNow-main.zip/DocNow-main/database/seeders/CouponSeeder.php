<?php

namespace Database\Seeders;

use App\Models\Coupon;
use Illuminate\Database\Seeder;

class CouponSeeder extends Seeder
{
    public function run(): void
    {
        Coupon::create([
            'code' => 'PRESENTATION',
            'discount_type' => 'percentage',
            'value' => 100.00,
            'is_active' => true,
        ]);
    }
}
