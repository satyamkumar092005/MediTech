interface RazorpayResponse {
    razorpay_payment_id: string;
    razorpay_order_id: string;
    razorpay_signature: string;
}

interface OrderData {
    order_id: string;
    amount: number;
    currency: string;
    key: string;
}

export function useRazorpay() {
    const loadScript = (): Promise<boolean> => {
        return new Promise((resolve) => {
            if (document.getElementById('razorpay-checkout-script')) {
                resolve(true);
                return;
            }
            const script = document.createElement('script');
            script.id = 'razorpay-checkout-script';
            script.src = 'https://checkout.razorpay.com/v1/checkout.js';
            script.onload = () => resolve(true);
            script.onerror = () => resolve(false);
            document.body.appendChild(script);
        });
    };

    const openCheckout = async (
        order: OrderData,
        onSuccess: (response: RazorpayResponse) => void,
        onError?: (error: any) => void
    ) => {
        const loaded = await loadScript();
        if (!loaded) {
            onError?.({ message: 'Failed to load payment gateway.' });
            return;
        }

        const options = {
            key: order.key,
            amount: order.amount,
            currency: order.currency,
            name: 'DocNow',
            description: 'Doctor Consultation',
            order_id: order.order_id,
            handler: (response: RazorpayResponse) => {
                onSuccess(response);
            },
            modal: {
                ondismiss: () => {
                    onError?.({ message: 'Payment cancelled.' });
                },
            },
            theme: { color: '#3b82f6' },
        };

        const rzp = new (window as any).Razorpay(options);
        rzp.open();
    };

    return { openCheckout };
}
