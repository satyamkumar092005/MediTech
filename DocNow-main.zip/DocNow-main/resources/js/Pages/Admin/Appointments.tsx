import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Calendar, Clock } from 'lucide-react';
import Pagination from '@/Components/Pagination';

interface Appointment {
    id: number;
    appointment_date: string;
    start_time: string;
    end_time: string;
    type: string;
    status: string;
    doctor: { user: { name: string } };
    patient: { user: { name: string } };
}

const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800',
    confirmed: 'bg-blue-100 text-blue-800',
    completed: 'bg-green-100 text-green-800',
    cancelled: 'bg-gray-100 text-gray-800',
};

export default function Appointments({ appointments }: { appointments: { data: Appointment[]; links: any[]; meta: any } }) {
    return (
        <AuthenticatedLayout header={<h2 className="text-xl font-semibold">All Appointments</h2>}>
            <Head title="Appointments" />

            <Card>
                <CardHeader>
                    <CardTitle>All Appointments</CardTitle>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>ID</TableHead>
                                <TableHead>Patient</TableHead>
                                <TableHead>Doctor</TableHead>
                                <TableHead>Date</TableHead>
                                <TableHead>Time</TableHead>
                                <TableHead>Type</TableHead>
                                <TableHead>Status</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {appointments.data.map((apt) => (
                                <TableRow key={apt.id}>
                                    <TableCell className="font-mono text-sm">#{apt.id}</TableCell>
                                    <TableCell className="font-medium">{apt.patient.user.name}</TableCell>
                                    <TableCell>{apt.doctor.user.name}</TableCell>
                                    <TableCell>
                                        <span className="flex items-center gap-1 text-sm"><Calendar className="h-3 w-3" />{apt.appointment_date}</span>
                                    </TableCell>
                                    <TableCell>
                                        <span className="flex items-center gap-1 text-sm"><Clock className="h-3 w-3" />{apt.start_time.slice(0,5)}-{apt.end_time.slice(0,5)}</span>
                                    </TableCell>
                                    <TableCell className="capitalize">{apt.type}</TableCell>
                                    <TableCell>
                                        <Badge className={statusColors[apt.status]}>
                                            {apt.status.charAt(0).toUpperCase() + apt.status.slice(1)}
                                        </Badge>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    {appointments.data.length === 0 && (
                        <p className="py-8 text-center text-muted-foreground">No appointments.</p>
                    )}
                    <Pagination links={appointments.links} meta={appointments.meta} />
                </CardContent>
            </Card>
        </AuthenticatedLayout>
    );
}
