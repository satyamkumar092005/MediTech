import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, router } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft } from 'lucide-react';

interface Specialization {
    id: number;
    name: string;
}

export default function CreateDoctor({ specializations }: { specializations: Specialization[] }) {
    const { data, setData, post, processing, errors } = useForm({
        name: '',
        email: '',
        password: '',
        specialization_id: '',
        license_number: '',
        qualifications: '',
        bio: '',
        years_of_experience: '',
        consultation_fee: '',
    });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        post('/admin/doctors', {
            onSuccess: () => router.visit('/admin/doctors'),
        });
    };

    return (
        <AuthenticatedLayout
            header={
                <div className="flex items-center gap-4">
                    <Button variant="ghost" size="icon" onClick={() => router.visit('/admin/doctors')}>
                        <ArrowLeft className="h-4 w-4" />
                    </Button>
                    <h2 className="text-xl font-semibold">Create Doctor</h2>
                </div>
            }
        >
            <Head title="Create Doctor" />

            <Card className="max-w-2xl mx-auto">
                <CardHeader>
                    <CardTitle>New Doctor Account</CardTitle>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label>Full Name</Label>
                                <Input value={data.name} onChange={(e) => setData('name', e.target.value)} />
                                {errors.name && <p className="text-sm text-destructive mt-1">{errors.name}</p>}
                            </div>
                            <div>
                                <Label>Email</Label>
                                <Input type="email" value={data.email} onChange={(e) => setData('email', e.target.value)} />
                                {errors.email && <p className="text-sm text-destructive mt-1">{errors.email}</p>}
                            </div>
                            <div>
                                <Label>Password</Label>
                                <Input type="password" value={data.password} onChange={(e) => setData('password', e.target.value)} />
                                {errors.password && <p className="text-sm text-destructive mt-1">{errors.password}</p>}
                            </div>
                            <div>
                                <Label>License Number</Label>
                                <Input value={data.license_number} onChange={(e) => setData('license_number', e.target.value)} />
                                {errors.license_number && <p className="text-sm text-destructive mt-1">{errors.license_number}</p>}
                            </div>
                            <div>
                                <Label>Specialization</Label>
                                <select
                                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                                    value={data.specialization_id}
                                    onChange={(e) => setData('specialization_id', e.target.value)}
                                >
                                    <option value="">Select...</option>
                                    {specializations.map((s) => (
                                        <option key={s.id} value={s.id}>{s.name}</option>
                                    ))}
                                </select>
                                {errors.specialization_id && <p className="text-sm text-destructive mt-1">{errors.specialization_id}</p>}
                            </div>
                            <div>
                                <Label>Years of Experience</Label>
                                <Input type="number" min={0} value={data.years_of_experience} onChange={(e) => setData('years_of_experience', e.target.value)} />
                                {errors.years_of_experience && <p className="text-sm text-destructive mt-1">{errors.years_of_experience}</p>}
                            </div>
                            <div>
                                <Label>Consultation Fee ($)</Label>
                                <Input type="number" min={0} step={0.01} value={data.consultation_fee} onChange={(e) => setData('consultation_fee', e.target.value)} />
                                {errors.consultation_fee && <p className="text-sm text-destructive mt-1">{errors.consultation_fee}</p>}
                            </div>
                        </div>
                        <div>
                            <Label>Qualifications</Label>
                            <Textarea value={data.qualifications} onChange={(e) => setData('qualifications', e.target.value)} />
                        </div>
                        <div>
                            <Label>Bio</Label>
                            <Textarea value={data.bio} onChange={(e) => setData('bio', e.target.value)} />
                        </div>
                        <Button type="submit" disabled={processing}>Create Doctor</Button>
                    </form>
                </CardContent>
            </Card>
        </AuthenticatedLayout>
    );
}
