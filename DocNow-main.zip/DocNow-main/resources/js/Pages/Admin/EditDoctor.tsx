import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, router } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft } from 'lucide-react';

interface Specialization {
    id: number;
    name: string;
}

interface Doctor {
    id: number;
    user: { id: number; name: string; email: string };
    license_number: string;
    qualifications: string | null;
    bio: string | null;
    years_of_experience: number;
    consultation_fee: string;
    specialization_id: number;
}

export default function EditDoctor({ doctor, specializations }: { doctor: Doctor; specializations: Specialization[] }) {
    const { data, setData, put, processing, errors } = useForm({
        name: doctor.user.name,
        email: doctor.user.email,
        specialization_id: String(doctor.specialization_id),
        license_number: doctor.license_number,
        qualifications: doctor.qualifications || '',
        bio: doctor.bio || '',
        years_of_experience: String(doctor.years_of_experience),
        consultation_fee: doctor.consultation_fee,
    });

    const handleSubmit = () => {
        put(`/admin/doctors/${doctor.id}`);
    };

    return (
        <AuthenticatedLayout
            header={
                <div className="flex items-center gap-4">
                    <Button variant="ghost" size="icon" onClick={() => router.visit('/admin/doctors')}>
                        <ArrowLeft className="h-4 w-4" />
                    </Button>
                    <h2 className="text-xl font-semibold">Edit Doctor</h2>
                </div>
            }
        >
            <Head title="Edit Doctor" />

            <Card className="max-w-2xl">
                <CardHeader>
                    <CardTitle>Edit {doctor.user.name}</CardTitle>
                </CardHeader>
                <CardContent>
                    <form onSubmit={(e) => { e.preventDefault(); handleSubmit(); }} className="space-y-4">
                        <div>
                            <Label>Full Name</Label>
                            <Input value={data.name} onChange={(e) => setData('name', e.target.value)} />
                            {errors.name && <p className="text-sm text-red-400 mt-1">{errors.name}</p>}
                        </div>
                        <div>
                            <Label>Email</Label>
                            <Input type="email" value={data.email} onChange={(e) => setData('email', e.target.value)} />
                            {errors.email && <p className="text-sm text-red-400 mt-1">{errors.email}</p>}
                        </div>
                        <div>
                            <Label>Specialization</Label>
                            <Select value={data.specialization_id} onValueChange={(v) => v && setData('specialization_id', v)}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    {specializations.map((s) => (
                                        <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            {errors.specialization_id && <p className="text-sm text-red-400 mt-1">{errors.specialization_id}</p>}
                        </div>
                        <div>
                            <Label>License Number</Label>
                            <Input value={data.license_number} onChange={(e) => setData('license_number', e.target.value)} />
                            {errors.license_number && <p className="text-sm text-red-400 mt-1">{errors.license_number}</p>}
                        </div>
                        <div>
                            <Label>Qualifications</Label>
                            <Textarea value={data.qualifications} onChange={(e) => setData('qualifications', e.target.value)} />
                        </div>
                        <div>
                            <Label>Bio</Label>
                            <Textarea value={data.bio} onChange={(e) => setData('bio', e.target.value)} />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label>Years of Experience</Label>
                                <Input type="number" value={data.years_of_experience} onChange={(e) => setData('years_of_experience', e.target.value)} />
                                {errors.years_of_experience && <p className="text-sm text-red-400 mt-1">{errors.years_of_experience}</p>}
                            </div>
                            <div>
                                <Label>Consultation Fee (₹)</Label>
                                <Input type="number" step="0.01" value={data.consultation_fee} onChange={(e) => setData('consultation_fee', e.target.value)} />
                                {errors.consultation_fee && <p className="text-sm text-red-400 mt-1">{errors.consultation_fee}</p>}
                            </div>
                        </div>
                        <Button type="submit" disabled={processing}>Update Doctor</Button>
                    </form>
                </CardContent>
            </Card>
        </AuthenticatedLayout>
    );
}
