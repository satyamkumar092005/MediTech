import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, router } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Star, Trash2, CheckCircle, XCircle } from 'lucide-react';
import Pagination from '@/Components/Pagination';

interface Rating {
    id: number;
    rating: number;
    review: string | null;
    is_approved: boolean;
    created_at: string;
    patient: { user: { name: string } };
    doctor: { user: { name: string } };
    appointment: { appointment_date: string };
}

export default function Ratings({ ratings }: { ratings: { data: Rating[]; links: any[]; meta: any } }) {
    return (
        <AuthenticatedLayout header={<h2 className="text-xl font-semibold">Rating Moderation</h2>}>
            <Head title="Rating Moderation" />

            <Card>
                <CardHeader>
                    <CardTitle>All Ratings</CardTitle>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Patient</TableHead>
                                <TableHead>Doctor</TableHead>
                                <TableHead>Rating</TableHead>
                                <TableHead>Review</TableHead>
                                <TableHead>Date</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {ratings.data.map((r) => (
                                <TableRow key={r.id}>
                                    <TableCell className="font-medium">{r.patient.user.name}</TableCell>
                                    <TableCell>{r.doctor.user.name}</TableCell>
                                    <TableCell>
                                        <div className="flex">
                                            {Array.from({ length: r.rating }).map((_, i) => (
                                                <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                            ))}
                                        </div>
                                    </TableCell>
                                    <TableCell className="max-w-xs truncate text-muted-foreground">{r.review || '—'}</TableCell>
                                    <TableCell className="text-sm text-muted-foreground">{r.appointment.appointment_date}</TableCell>
                                    <TableCell>
                                        <Badge variant={r.is_approved ? 'default' : 'secondary'}>
                                            {r.is_approved ? 'Approved' : 'Pending'}
                                        </Badge>
                                    </TableCell>
                                    <TableCell>
                                        <div className="flex gap-1">
                                            <Button
                                                variant="ghost"
                                                size="icon"
                                                onClick={() => router.patch(`/admin/ratings/${r.id}/approve`)}
                                            >
                                                {r.is_approved ? <XCircle className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
                                            </Button>
                                            <Button
                                                variant="ghost"
                                                size="icon"
                                                onClick={() => { if (confirm('Delete this rating?')) router.delete(`/admin/ratings/${r.id}`); }}
                                            >
                                                <Trash2 className="h-4 w-4 text-destructive" />
                                            </Button>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    {ratings.data.length === 0 && (
                        <p className="py-8 text-center text-muted-foreground">No ratings yet.</p>
                    )}
                    <Pagination links={ratings.links} meta={ratings.meta} />
                </CardContent>
            </Card>
        </AuthenticatedLayout>
    );
}
