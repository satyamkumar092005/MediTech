import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, router } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import Pagination from '@/Components/Pagination';

interface Doctor {
    id: number;
    license_number: string;
    qualifications: string | null;
    years_of_experience: number;
    consultation_fee: string;
    user: { name: string; email: string };
    specialization: { name: string };
}

export default function Doctors({ doctors }: { doctors: { data: Doctor[]; links: any[]; meta: any } }) {
    return (
        <AuthenticatedLayout
            header={
                <div className="flex items-center justify-between">
                    <h2 className="text-xl font-semibold">Doctors</h2>
                    <Button onClick={() => router.visit('/admin/doctors/create')}>
                        <Plus className="mr-2 h-4 w-4" /> Add Doctor
                    </Button>
                </div>
            }
        >
            <Head title="Doctors" />

            <Card>
                <CardHeader>
                    <CardTitle>All Doctors</CardTitle>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Doctor</TableHead>
                                <TableHead>Specialization</TableHead>
                                <TableHead>License</TableHead>
                                <TableHead>Experience</TableHead>
                                <TableHead>Fee</TableHead>
                                <TableHead>Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {doctors.data.map((doctor) => (
                                <TableRow key={doctor.id}>
                                    <TableCell className="flex items-center gap-2">
                                        <Avatar className="h-8 w-8">
                                            <AvatarFallback>{doctor.user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}</AvatarFallback>
                                        </Avatar>
                                        <div>
                                            <p className="font-medium">{doctor.user.name}</p>
                                            <p className="text-xs text-muted-foreground">{doctor.user.email}</p>
                                        </div>
                                    </TableCell>
                                    <TableCell><Badge variant="outline">{doctor.specialization.name}</Badge></TableCell>
                                    <TableCell className="text-sm text-muted-foreground">{doctor.license_number}</TableCell>
                                    <TableCell>{doctor.years_of_experience}yrs</TableCell>
                                    <TableCell>₹{parseFloat(doctor.consultation_fee).toFixed(0)}</TableCell>
                                    <TableCell>
                                        <div className="flex gap-1">
                                            <Button variant="ghost" size="icon" onClick={() => router.visit(`/admin/doctors/${doctor.id}/edit`)}>
                                                <Pencil className="h-4 w-4" />
                                            </Button>
                                            <Button variant="ghost" size="icon" onClick={() => { if (confirm('Delete this doctor?')) router.delete(`/admin/doctors/${doctor.id}`); }}>
                                                <Trash2 className="h-4 w-4 text-destructive" />
                                            </Button>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    {doctors.data.length === 0 && (
                        <p className="py-8 text-center text-muted-foreground">No doctors found.</p>
                    )}
                    <Pagination links={doctors.links} meta={doctors.meta} />
                </CardContent>
            </Card>
        </AuthenticatedLayout>
    );
}
