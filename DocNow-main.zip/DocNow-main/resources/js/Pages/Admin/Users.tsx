import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, router } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Trash2, Shield } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Pagination from '@/Components/Pagination';

interface User {
    id: number;
    name: string;
    email: string;
    created_at: string;
    roles: { name: string }[];
}

const roleColors: Record<string, string> = {
    admin: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
    doctor: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    patient: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
};

export default function Users({ users }: { users: { data: User[]; links: any[]; meta: any } }) {
    const handleRoleChange = (userId: number, role: string) => {
        router.patch(`/admin/users/${userId}/role`, { role });
    };

    const handleDelete = (user: User) => {
        if (confirm(`Delete user "${user.name}"? This cannot be undone.`)) {
            router.delete(`/admin/users/${user.id}`);
        }
    };

    return (
        <AuthenticatedLayout header={<h2 className="text-xl font-semibold">Users</h2>}>
            <Head title="Users" />

            <Card>
                <CardHeader>
                    <CardTitle>All Users</CardTitle>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>User</TableHead>
                                <TableHead>Email</TableHead>
                                <TableHead>Role</TableHead>
                                <TableHead>Joined</TableHead>
                                <TableHead>Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {users.data.map((user) => (
                                <TableRow key={user.id}>
                                    <TableCell className="flex items-center gap-2">
                                        <Avatar className="h-8 w-8">
                                            <AvatarFallback>{user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}</AvatarFallback>
                                        </Avatar>
                                        <span className="font-medium">{user.name}</span>
                                    </TableCell>
                                    <TableCell className="text-muted-foreground">{user.email}</TableCell>
                                    <TableCell>
                                        <Select
                                            value={user.roles[0]?.name || 'patient'}
                                            onValueChange={(v) => v && handleRoleChange(user.id, v)}
                                        >
                                            <SelectTrigger className="h-8 w-32">
                                                <SelectValue>
                                                    <Badge className={roleColors[user.roles[0]?.name || 'patient']}>
                                                        {user.roles[0]?.name || 'patient'}
                                                    </Badge>
                                                </SelectValue>
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="admin">
                                                    <Badge className={roleColors.admin}>admin</Badge>
                                                </SelectItem>
                                                <SelectItem value="doctor">
                                                    <Badge className={roleColors.doctor}>doctor</Badge>
                                                </SelectItem>
                                                <SelectItem value="patient">
                                                    <Badge className={roleColors.patient}>patient</Badge>
                                                </SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </TableCell>
                                    <TableCell className="text-muted-foreground">{user.created_at?.slice(0, 10)}</TableCell>
                                    <TableCell>
                                        <Button variant="ghost" size="icon" onClick={() => handleDelete(user)}>
                                            <Trash2 className="h-4 w-4 text-destructive" />
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    {users.data.length === 0 && (
                        <p className="py-8 text-center text-muted-foreground">No users found.</p>
                    )}
                    <Pagination links={users.links} meta={users.meta} />
                </CardContent>
            </Card>
        </AuthenticatedLayout>
    );
}
