import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, router } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Pencil, Trash2, X, Check } from 'lucide-react';
import { useState } from 'react';

interface Specialization {
    id: number;
    name: string;
    slug: string;
    description: string | null;
    icon: string | null;
}

export default function Specializations({ specializations }: { specializations: Specialization[] }) {
    const [editingId, setEditingId] = useState<number | null>(null);
    const [editForm, setEditForm] = useState({ name: '', slug: '', description: '' });

    const { data, setData, post, processing, reset } = useForm({
        name: '',
        slug: '',
        description: '',
    });

    const handleCreate = (e: React.FormEvent) => {
        e.preventDefault();
        post('/admin/specializations', {
            preserveScroll: true,
            onSuccess: () => reset(),
        });
    };

    const handleEdit = (s: Specialization) => {
        setEditingId(s.id);
        setEditForm({ name: s.name, slug: s.slug, description: s.description || '' });
    };

    const handleUpdate = (id: number) => {
        router.put(`/admin/specializations/${id}`, editForm, {
            preserveScroll: true,
            onSuccess: () => setEditingId(null),
        });
    };

    const handleDelete = (id: number) => {
        if (confirm('Delete this specialization?')) {
            router.delete(`/admin/specializations/${id}`, { preserveScroll: true });
        }
    };

    return (
        <AuthenticatedLayout header={<h2 className="text-xl font-semibold">Specializations</h2>}>
            <Head title="Specializations" />

            <div className="grid gap-6 lg:grid-cols-3">
                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">Add Specialization</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleCreate} className="space-y-4">
                            <div>
                                <Label>Name</Label>
                                <Input value={data.name} onChange={(e) => setData('name', e.target.value)} />
                            </div>
                            <div>
                                <Label>Slug</Label>
                                <Input value={data.slug} onChange={(e) => setData('slug', e.target.value)} placeholder="e.g., cardiology" />
                            </div>
                            <div>
                                <Label>Description</Label>
                                <Input value={data.description || ''} onChange={(e) => setData('description', e.target.value)} />
                            </div>
                            <Button type="submit" disabled={processing}>
                                <Plus className="mr-2 h-4 w-4" /> Create
                            </Button>
                        </form>
                    </CardContent>
                </Card>

                <Card className="lg:col-span-2">
                    <CardHeader>
                        <CardTitle>All Specializations</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Name</TableHead>
                                    <TableHead>Slug</TableHead>
                                    <TableHead>Description</TableHead>
                                    <TableHead className="w-24">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {specializations.map((s) => (
                                    <TableRow key={s.id}>
                                        {editingId === s.id ? (
                                            <>
                                                <TableCell>
                                                    <Input value={editForm.name} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} />
                                                </TableCell>
                                                <TableCell>
                                                    <Input value={editForm.slug} onChange={(e) => setEditForm({ ...editForm, slug: e.target.value })} />
                                                </TableCell>
                                                <TableCell>
                                                    <Input value={editForm.description} onChange={(e) => setEditForm({ ...editForm, description: e.target.value })} />
                                                </TableCell>
                                                <TableCell>
                                                    <div className="flex gap-1">
                                                        <Button variant="ghost" size="icon" onClick={() => handleUpdate(s.id)}>
                                                            <Check className="h-4 w-4 text-green-600" />
                                                        </Button>
                                                        <Button variant="ghost" size="icon" onClick={() => setEditingId(null)}>
                                                            <X className="h-4 w-4" />
                                                        </Button>
                                                    </div>
                                                </TableCell>
                                            </>
                                        ) : (
                                            <>
                                                <TableCell className="font-medium">{s.name}</TableCell>
                                                <TableCell className="text-muted-foreground">{s.slug}</TableCell>
                                                <TableCell className="text-muted-foreground text-sm">{s.description || '-'}</TableCell>
                                                <TableCell>
                                                    <div className="flex gap-1">
                                                        <Button variant="ghost" size="icon" onClick={() => handleEdit(s)}>
                                                            <Pencil className="h-4 w-4" />
                                                        </Button>
                                                        <Button variant="ghost" size="icon" onClick={() => handleDelete(s.id)}>
                                                            <Trash2 className="h-4 w-4 text-destructive" />
                                                        </Button>
                                                    </div>
                                                </TableCell>
                                            </>
                                        )}
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                        {specializations.length === 0 && (
                            <p className="py-8 text-center text-muted-foreground">No specializations.</p>
                        )}
                    </CardContent>
                </Card>
            </div>
        </AuthenticatedLayout>
    );
}
