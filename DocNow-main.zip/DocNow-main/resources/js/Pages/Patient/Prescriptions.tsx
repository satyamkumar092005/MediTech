import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Pill, FileText } from 'lucide-react';
import Pagination from '@/Components/Pagination';

interface Prescription {
    id: number;
    doctor: { user: { name: string } };
    appointment_id: number;
    notes: string | null;
    follow_up_date: string | null;
    is_filled: boolean;
    created_at: string;
    items: { id: number; medicine_name: string; dosage: string }[];
}

export default function Prescriptions({ prescriptions }: { prescriptions: { data: Prescription[]; links: any[]; meta: any } }) {
    return (
        <AuthenticatedLayout header={<h2 className="text-xl font-semibold">My Prescriptions</h2>}>
            <Head title="Prescriptions" />

            <div className="space-y-4">
                {prescriptions.data.length === 0 && (
                    <Card>
                        <CardContent className="py-12 text-center">
                            <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                            <p className="text-muted-foreground">No prescriptions yet.</p>
                        </CardContent>
                    </Card>
                )}
                {prescriptions.data.map((prescription) => (
                    <Link key={prescription.id} href={`/patient/prescriptions/${prescription.id}`}>
                        <Card className="transition-shadow hover:shadow-md">
                            <CardContent className="pt-6">
                                <div className="flex items-start justify-between">
                                    <div>
                                        <div className="flex items-center gap-2 mb-1">
                                            <h3 className="font-semibold">Dr. {prescription.doctor.user.name}</h3>
                                            <Badge variant={prescription.is_filled ? 'default' : 'secondary'}>
                                                {prescription.is_filled ? 'Filled' : 'Pending'}
                                            </Badge>
                                        </div>
                                        <p className="text-sm text-muted-foreground">
                                            {new Date(prescription.created_at).toLocaleDateString()}
                                        </p>
                                        <div className="mt-2 flex flex-wrap gap-2">
                                            {prescription.items.slice(0, 3).map((item) => (
                                                <Badge key={item.id} variant="outline" className="flex items-center gap-1">
                                                    <Pill className="h-3 w-3" />
                                                    {item.medicine_name}
                                                </Badge>
                                            ))}
                                            {prescription.items.length > 3 && (
                                                <Badge variant="outline">+{prescription.items.length - 3} more</Badge>
                                            )}
                                        </div>
                                    </div>
                                    <Button variant="ghost" size="sm">
                                        <FileText className="h-4 w-4" />
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    </Link>
                ))}
                <Pagination links={prescriptions.links} meta={prescriptions.meta} />
            </div>
        </AuthenticatedLayout>
    );
}
