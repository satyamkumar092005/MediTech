import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Pill, Calendar, FileText, ArrowLeft, Star, Clock, MapPin, Video } from 'lucide-react';

interface Appointment {
    id: number;
    doctor: { user: { name: string }; specialization: { name: string } };
    appointment_date: string;
    start_time: string;
    end_time: string;
    type: 'virtual';
    status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
    notes: string | null;
    meeting_link: string | null;
    consultation_summary: string | null;
    prescription: { id: number; items: { id: number; medicine_name: string; dosage: string; frequency: string; duration: string }[] } | null;
    rating: { id: number; rating: number; review: string | null } | null;
}

const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800',
    confirmed: 'bg-blue-100 text-blue-800',
    completed: 'bg-green-100 text-green-800',
    cancelled: 'bg-gray-100 text-gray-800',
};

export default function AppointmentDetail({ appointment }: { appointment: Appointment }) {
    return (
        <AuthenticatedLayout
            header={
                <div className="flex items-center gap-4">
                    <Link href="/patient/appointments">
                        <Button variant="ghost" size="icon">
                            <ArrowLeft className="h-4 w-4" />
                        </Button>
                    </Link>
                    <h2 className="text-xl font-semibold">Appointment #{appointment.id}</h2>
                </div>
            }
        >
            <Head title="Appointment Details" />

            <div className="grid gap-6 lg:grid-cols-3">
                <div className="lg:col-span-2">
                    <Card>
                        <CardHeader>
                            <div className="flex items-start justify-between">
                                <div>
                                    <CardTitle>{appointment.doctor.user.name}</CardTitle>
                                    <p className="text-sm text-muted-foreground">{appointment.doctor.specialization.name}</p>
                                </div>
                                <Badge className={statusColors[appointment.status]}>
                                    {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                                </Badge>
                            </div>
                        </CardHeader>
                        <CardContent>
                            <div className="flex flex-wrap gap-4 text-sm mb-4">
                                <span className="flex items-center gap-1"><Calendar className="h-4 w-4" /> {appointment.appointment_date}</span>
                                <span className="flex items-center gap-1"><Clock className="h-4 w-4" /> {appointment.start_time.slice(0,5)} - {appointment.end_time.slice(0,5)}</span>
                                <span className="flex items-center gap-1">
                                            {appointment.type === 'virtual' ? <Video className="h-4 w-4" /> : <MapPin className="h-4 w-4" />}
                                            Virtual
                                </span>
                            </div>

                            {appointment.notes && (
                                <div>
                                    <h4 className="text-sm font-medium mb-1">Your Notes</h4>
                                    <p className="text-sm text-muted-foreground">{appointment.notes}</p>
                                </div>
                            )}

                            {appointment.consultation_summary && (
                                <div className="mt-4">
                                    <h4 className="text-sm font-medium mb-1">Consultation Summary</h4>
                                    <div className="rounded-lg border p-3 text-sm text-muted-foreground whitespace-pre-wrap">
                                        {appointment.consultation_summary}
                                    </div>
                                </div>
                            )}

                            {appointment.meeting_link && appointment.type === 'virtual' && (
                                <a href={appointment.meeting_link} target="_blank" rel="noopener noreferrer">
                                    <Button className="mt-4">
                                        <Video className="mr-2 h-4 w-4" /> Join Virtual Visit
                                    </Button>
                                </a>
                            )}
                        </CardContent>
                    </Card>

                    {appointment.prescription && (
                        <Card className="mt-6">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Pill className="h-5 w-5" />
                                    Prescription
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-2">
                                    {appointment.prescription.items.map((item) => (
                                        <div key={item.id} className="rounded-lg border p-3">
                                            <p className="font-medium">{item.medicine_name}</p>
                                            <p className="text-sm text-muted-foreground">{item.dosage} - {item.frequency} - {item.duration}</p>
                                        </div>
                                    ))}
                                </div>
                                <Link href={`/patient/prescriptions/${appointment.prescription.id}`}>
                                    <Button variant="outline" className="mt-4">View Full Prescription</Button>
                                </Link>
                            </CardContent>
                        </Card>
                    )}
                </div>

                <div>
                    {appointment.status === 'completed' && !appointment.rating && (
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-lg">
                                    <Star className="h-5 w-5" />
                                    Rate Your Visit
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <Link href={`/patient/appointments/${appointment.id}/rate`}>
                                    <Button className="w-full">Write a Review</Button>
                                </Link>
                            </CardContent>
                        </Card>
                    )}

                    {appointment.rating && (
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-lg">Your Rating</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="flex mb-2">
                                    {Array.from({ length: appointment.rating.rating }).map((_, i) => (
                                        <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                                    ))}
                                </div>
                                {appointment.rating.review && (
                                    <p className="text-sm text-muted-foreground">{appointment.rating.review}</p>
                                )}
                            </CardContent>
                        </Card>
                    )}
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
