import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, useForm } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Star } from 'lucide-react';
import { useState } from 'react';

export default function RateDoctor({ appointment }: { appointment: any }) {
    const [hoverRating, setHoverRating] = useState(0);
    const { data, setData, post, processing, errors } = useForm({
        appointment_id: appointment.id,
        rating: 0,
        review: '',
    });

    const handleSubmit = () => {
        post('/patient/ratings');
    };

    return (
        <AuthenticatedLayout
            header={
                <div className="flex items-center gap-4">
                    <Link href={`/patient/appointments/${appointment.id}`}>
                        <Button variant="ghost" size="icon">
                            <ArrowLeft className="h-4 w-4" />
                        </Button>
                    </Link>
                    <h2 className="text-xl font-semibold">Rate Your Visit</h2>
                </div>
            }
        >
            <Head title="Rate Doctor" />

            <div className="mx-auto max-w-lg">
                <Card>
                    <CardHeader className="text-center">
                        <CardTitle>How was your visit with {appointment.doctor.user.name}?</CardTitle>
                        <p className="text-sm text-muted-foreground">
                            {appointment.doctor.specialization.name} — {appointment.appointment_date}
                        </p>
                    </CardHeader>
                    <CardContent>
                        <div className="mb-6 text-center">
                            <Label className="mb-2 block">Your Rating</Label>
                            <div className="flex justify-center gap-1">
                                {[1, 2, 3, 4, 5].map((star) => (
                                    <button
                                        key={star}
                                        type="button"
                                        onMouseEnter={() => setHoverRating(star)}
                                        onMouseLeave={() => setHoverRating(0)}
                                        onClick={() => setData('rating', star)}
                                        className="transition-transform hover:scale-110"
                                    >
                                        <Star
                                            className={`h-10 w-10 ${
                                                star <= (hoverRating || data.rating)
                                                    ? 'fill-yellow-400 text-yellow-400'
                                                    : 'text-muted-foreground/30'
                                            }`}
                                        />
                                    </button>
                                ))}
                            </div>
                            {errors.rating && (
                                <p className="mt-2 text-sm text-destructive">{errors.rating}</p>
                            )}
                        </div>

                        <div className="mb-6">
                            <Label htmlFor="review">Write a Review (optional)</Label>
                            <Textarea
                                id="review"
                                placeholder="Share your experience..."
                                value={data.review}
                                onChange={(e) => setData('review', e.target.value)}
                                rows={4}
                            />
                        </div>

                        <Button
                            className="w-full"
                            onClick={handleSubmit}
                            disabled={processing || data.rating === 0}
                        >
                            Submit Rating
                        </Button>
                    </CardContent>
                </Card>
            </div>
        </AuthenticatedLayout>
    );
}
