import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, router } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Pill, Calendar, ArrowLeft, CheckCircle, XCircle } from 'lucide-react';

interface PrescriptionItem {
    id: number;
    medicine_name: string;
    dosage: string;
    frequency: string;
    duration: string;
    instructions: string | null;
}

interface Prescription {
    id: number;
    doctor: { user: { name: string } };
    appointment_id: number;
    notes: string | null;
    follow_up_date: string | null;
    is_filled: boolean;
    created_at: string;
    items: PrescriptionItem[];
}

export default function PrescriptionDetail({ prescription }: { prescription: Prescription }) {
    const toggleFill = () => {
        router.patch(`/patient/prescriptions/${prescription.id}/fill`, {}, {
            preserveScroll: true,
        });
    };

    return (
        <AuthenticatedLayout
            header={
                <div className="flex items-center gap-4">
                    <Link href="/patient/prescriptions">
                        <Button variant="ghost" size="icon">
                            <ArrowLeft className="h-4 w-4" />
                        </Button>
                    </Link>
                    <h2 className="text-xl font-semibold">Prescription #{prescription.id}</h2>
                </div>
            }
        >
            <Head title="Prescription Details" />

            <Card className="mb-6">
                <CardHeader>
                    <div className="flex items-start justify-between">
                        <div>
                            <CardTitle>Dr. {prescription.doctor.user.name}</CardTitle>
                            <p className="text-sm text-muted-foreground">
                                {new Date(prescription.created_at).toLocaleDateString()}
                            </p>
                        </div>
                        <Badge variant={prescription.is_filled ? 'default' : 'secondary'}>
                            {prescription.is_filled ? 'Filled' : 'Pending'}
                        </Badge>
                    </div>
                </CardHeader>
                <CardContent>
                    {prescription.notes && (
                        <div className="mb-4">
                            <h4 className="text-sm font-medium mb-1">Notes</h4>
                            <p className="text-sm text-muted-foreground">{prescription.notes}</p>
                        </div>
                    )}

                    <h4 className="text-sm font-medium mb-3">Medicines</h4>
                    <div className="space-y-3">
                        {prescription.items.map((item) => (
                            <div key={item.id} className="rounded-lg border p-3">
                                <div className="flex items-start justify-between">
                                    <div>
                                        <p className="font-medium flex items-center gap-2">
                                            <Pill className="h-4 w-4 text-primary" />
                                            {item.medicine_name}
                                        </p>
                                        <p className="text-sm text-muted-foreground mt-1">
                                            {item.dosage} — {item.frequency} — {item.duration}
                                        </p>
                                    </div>
                                </div>
                                {item.instructions && (
                                    <p className="mt-2 text-sm text-muted-foreground border-t pt-2">
                                        {item.instructions}
                                    </p>
                                )}
                            </div>
                        ))}
                    </div>

                    {prescription.follow_up_date && (
                        <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
                            <Calendar className="h-4 w-4" />
                            Follow-up: {prescription.follow_up_date}
                        </div>
                    )}
                </CardContent>
            </Card>

            <div className="flex gap-2">
                <Button
                    variant={prescription.is_filled ? 'outline' : 'default'}
                    onClick={toggleFill}
                >
                    {prescription.is_filled ? (
                        <><XCircle className="mr-2 h-4 w-4" /> Mark as Pending</>
                    ) : (
                        <><CheckCircle className="mr-2 h-4 w-4" /> Mark as Filled</>
                    )}
                </Button>
                <Link href={`/patient/appointments/${prescription.appointment_id}`}>
                    <Button variant="outline">View Appointment</Button>
                </Link>
            </div>
        </AuthenticatedLayout>
    );
}
