import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, router } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Search, Star, IndianRupee } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useState } from 'react';
import Pagination from '@/Components/Pagination';

interface Doctor {
    id: number;
    user: { name: string; avatar?: string };
    specialization: { name: string };
    consultation_fee: number;
    years_of_experience: number;
    bio: string;
    average_rating: number | null;
    review_count: number;
}

export default function DoctorsIndex({ doctors, specializations, filters }: {
    doctors: { data: Doctor[]; links: any[]; meta: any };
    specializations: { id: number; name: string }[];
    filters: { specialization?: string; search?: string };
}) {
    const [search, setSearch] = useState(filters.search || '');
    const [specialization, setSpecialization] = useState(filters.specialization || '');

    const handleFilter = () => {
        router.get('/patient/doctors', { search, specialization }, { preserveState: true });
    };

    return (
        <AuthenticatedLayout header={<h2 className="text-xl font-semibold">Find a Doctor</h2>}>
            <Head title="Find Doctors" />

            <Card className="mb-6">
                <CardContent className="pt-6">
                    <div className="flex flex-col gap-4 md:flex-row">
                        <div className="flex-1">
                            <Label htmlFor="search">Search</Label>
                            <div className="relative">
                                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                                <Input
                                    id="search"
                                    placeholder="Search by doctor name..."
                                    className="pl-9"
                                    value={search}
                                    onChange={(e) => setSearch(e.target.value)}
                                />
                            </div>
                        </div>
                        <div className="w-full md:w-48">
                            <Label htmlFor="specialization">Specialization</Label>
                            <select
                                id="specialization"
                                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                                value={specialization}
                                onChange={(e) => setSpecialization(e.target.value)}
                            >
                                <option value="">All</option>
                                {specializations.map((s) => (
                                    <option key={s.id} value={s.id}>{s.name}</option>
                                ))}
                            </select>
                        </div>
                        <div className="flex items-end">
                            <Button onClick={handleFilter}>Search</Button>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {doctors.data.map((doctor) => (
                    <Link
                        key={doctor.id}
                        href={`/patient/doctors/${doctor.id}`}
                        className="block"
                    >
                        <Card className="transition-shadow hover:shadow-lg">
                            <CardHeader>
                                <div className="flex items-start justify-between">
                                    <div className="flex items-center gap-3">
                                        <Avatar className="h-10 w-10">
                                            {doctor.user.avatar ? <AvatarImage src={doctor.user.avatar} /> : null}
                                            <AvatarFallback>{doctor.user.name.split(' ').filter(Boolean).slice(-1)[0]?.[0] || 'D'}</AvatarFallback>
                                        </Avatar>
                                        <div>
                                            <CardTitle className="text-lg">{doctor.user.name}</CardTitle>
                                            <p className="text-sm text-muted-foreground">
                                                {doctor.specialization.name}
                                            </p>
                                        </div>
                                    </div>
                                    {doctor.average_rating && (
                                        <Badge variant="secondary" className="flex items-center gap-1">
                                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                                            {Number(doctor.average_rating).toFixed(1)}
                                        </Badge>
                                    )}
                                </div>
                            </CardHeader>
                            <CardContent>
                                <p className="mb-2 text-sm text-muted-foreground line-clamp-2">
                                    {doctor.bio}
                                </p>
                                <div className="flex items-center justify-between text-sm">
                                    <span>{doctor.years_of_experience} yrs exp.</span>
                                    <span className="font-semibold flex items-center gap-1">
                                        <IndianRupee className="h-3 w-3" />{doctor.consultation_fee}
                                    </span>
                                </div>
                            </CardContent>
                        </Card>
                    </Link>
                ))}
                {doctors.data.length === 0 && (
                    <p className="col-span-full text-center text-muted-foreground py-12">
                        No doctors found.
                    </p>
                )}
            </div>
            <Pagination links={doctors.links} meta={doctors.meta} />
        </AuthenticatedLayout>
    );
}
