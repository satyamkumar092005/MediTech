import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, router, usePage } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Calendar, Clock, DollarSign, Star, Award, Video, User, Loader2, AlertCircle } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useState } from 'react';
import { useRazorpay } from '@/hooks/use-razorpay';
import axios from 'axios';

interface Schedule {
    id: number;
    day_of_week: number;
    start_time: string;
    end_time: string;
    slot_duration_minutes: number;
}

interface Doctor {
    id: number;
    user: { name: string; avatar?: string };
    specialization: { name: string; description?: string };
    consultation_fee: number;
    years_of_experience: number;
    bio: string;
    qualifications: string;
    license_number: string;
    schedules: Schedule[];
    average_rating: number | null;
    review_count: number;
    ratings: { id: number; rating: number; review: string; patient: { user: { name: string } } }[];
}

const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function DoctorProfile({ doctor }: { doctor: Doctor }) {
    const { errors: pageErrors } = usePage().props;
    const [selectedDate, setSelectedDate] = useState('');
    const [selectedTime, setSelectedTime] = useState('');
    const [activeTab, setActiveTab] = useState<'about' | 'schedule' | 'reviews'>('about');
    const [paying, setPaying] = useState(false);
    const [promoCode, setPromoCode] = useState('');
    const [discountInfo, setDiscountInfo] = useState<{ coupon_id: number; discount: number; new_amount: number; code: string } | null>(null);
    const [promoError, setPromoError] = useState('');
    const { openCheckout } = useRazorpay();

    const { data, setData, processing } = useForm({
        doctor_id: doctor.id,
        appointment_date: '',
        start_time: '',
        end_time: '',
        type: 'virtual' as const,
        notes: '',
        payment_id: '',
        razorpay_order_id: '',
        razorpay_signature: '',
        coupon_id: null as number | null,
        is_free: false,
    });

    // Combine form errors and page errors
    const allErrors = { ...pageErrors };

    const finalAmount = discountInfo ? discountInfo.new_amount : doctor.consultation_fee;

    const applyPromo = async () => {
        setPromoError('');
        try {
            const res = await axios.post('/patient/coupons/validate', {
                code: promoCode,
                amount: doctor.consultation_fee
            });
            setDiscountInfo(res.data);
            setData('coupon_id', res.data.coupon_id);
        } catch (e: any) {
            setPromoError(e.response?.data?.error || 'Invalid code');
            setDiscountInfo(null);
            setData('coupon_id', null);
        }
    };

    const handlePayAndBook = async () => {
        if (!selectedTime || !selectedDate) return;
        setPaying(true);

        if (finalAmount <= 0) {
            router.post('/patient/appointments', {
                ...data,
                appointment_date: selectedDate,
                start_time: selectedTime,
                is_free: true,
                payment_id: `promo_${discountInfo?.code}_${Date.now()}`,
                coupon_id: discountInfo?.coupon_id || null,
            }, {
                preserveScroll: true,
                onSuccess: () => router.visit('/patient/appointments'),
                onError: () => setPaying(false),
                onFinish: () => setPaying(false),
            });
            return;
        }

        try {
            const orderRes = await axios.post('/patient/payment/create-order', {
                amount: finalAmount,
                doctor_id: doctor.id,
            });
            const order = orderRes.data;

            openCheckout(
                order,
                async (response) => {
                    router.post('/patient/appointments', {
                        ...data,
                        appointment_date: selectedDate,
                        start_time: selectedTime,
                        payment_id: response.razorpay_payment_id,
                        razorpay_order_id: response.razorpay_order_id,
                        razorpay_signature: response.razorpay_signature,
                        coupon_id: discountInfo?.coupon_id || null,
                    }, {
                        preserveScroll: true,
                        onSuccess: () => router.visit('/patient/appointments'),
                        onError: () => setPaying(false),
                        onFinish: () => setPaying(false),
                    });
                },
                () => setPaying(false)
            );
        } catch (error) {
            console.error('Payment order creation failed', error);
            setPaying(false);
        }
    };

    const handleInstantPay = async () => {
        setPaying(true);

        if (finalAmount <= 0) {
            router.post('/patient/appointments/instant', {
                doctor_id: doctor.id,
                payment_id: `promo_${discountInfo?.code}_${Date.now()}`,
                coupon_id: discountInfo?.coupon_id || null,
                is_free: true,
            }, {
                onError: () => setPaying(false),
                onFinish: () => setPaying(false),
            });
            return;
        }

        try {
            const orderRes = await axios.post('/patient/payment/create-order', {
                amount: finalAmount,
                doctor_id: doctor.id,
            });
            const order = orderRes.data;

            openCheckout(
                order,
                async (response) => {
                    router.post('/patient/appointments/instant', {
                        doctor_id: doctor.id,
                        payment_id: response.razorpay_payment_id,
                        razorpay_order_id: response.razorpay_order_id,
                        razorpay_signature: response.razorpay_signature,
                        coupon_id: discountInfo?.coupon_id || null,
                    }, {
                        onError: () => setPaying(false),
                        onFinish: () => setPaying(false),
                    });
                },
                () => setPaying(false)
            );
        } catch (error) {
            console.error('Instant payment order creation failed', error);
            setPaying(false);
        }
    };

    const generateTimeSlots = () => {
        const today = new Date();
        const selected = new Date(selectedDate);
        const dayOfWeek = selected.getDay();
        const schedule = doctor.schedules.find((s) => s.day_of_week === dayOfWeek);
        if (!schedule) return [];

        const slots: { start: string; end: string }[] = [];
        const [startH, startM] = schedule.start_time.split(':').map(Number);
        const [endH, endM] = schedule.end_time.split(':').map(Number);
        let current = startH * 60 + startM;
        const end = endH * 60 + endM;
        const duration = schedule.slot_duration_minutes;

        while (current + duration <= end) {
            const h = Math.floor(current / 60);
            const m = current % 60;
            const next = current + duration;
            const nh = Math.floor(next / 60);
            const nm = next % 60;
            slots.push({
                start: `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`,
                end: `${String(nh).padStart(2, '0')}:${String(nm).padStart(2, '0')}`,
            });
            current = next;
        }
        return slots;
    };

    const slots = generateTimeSlots();

    return (
        <AuthenticatedLayout
            header={<h2 className="text-xl font-semibold">Doctor Profile</h2>}
        >
            <Head title={doctor.user.name} />

            <div className="grid gap-6 lg:grid-cols-3">
                <div className="lg:col-span-2">
                    <Card>
                        <CardHeader>
                            <div className="flex items-start justify-between">
                                <div className="flex items-center gap-4">
                                    <Avatar className="h-14 w-14">
                                        {doctor.user.avatar ? <AvatarImage src={doctor.user.avatar} /> : null}
                                        <AvatarFallback className="text-lg">{doctor.user.name.split(' ').filter(Boolean).slice(-1)[0]?.[0] || 'D'}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <CardTitle className="text-2xl">{doctor.user.name}</CardTitle>
                                        <p className="text-muted-foreground">{doctor.specialization.name}</p>
                                    </div>
                                </div>
                                {doctor.average_rating && (
                                    <Badge variant="secondary" className="flex items-center gap-1 text-lg px-3 py-1">
                                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                        {Number(doctor.average_rating).toFixed(1)}
                                        <span className="text-xs text-muted-foreground">({doctor.review_count})</span>
                                    </Badge>
                                )}
                            </div>
                        </CardHeader>
                        <CardContent>
                            <div className="mb-4 flex flex-wrap gap-4 text-sm">
                                <span className="flex items-center gap-1"><Award className="h-4 w-4" /> {doctor.years_of_experience} years exp.</span>
                                <span className="flex items-center gap-1"><DollarSign className="h-4 w-4" /> ₹{doctor.consultation_fee}</span>
                                <span className="flex items-center gap-1"><User className="h-4 w-4" /> {doctor.qualifications}</span>
                            </div>

                            <div className="mb-4 flex gap-2 border-b">
                                {(['about', 'schedule', 'reviews'] as const).map((tab) => (
                                    <button
                                        key={tab}
                                        onClick={() => setActiveTab(tab)}
                                        className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                                            activeTab === tab
                                                ? 'border-primary text-primary'
                                                : 'border-transparent text-muted-foreground hover:text-foreground'
                                        }`}
                                    >
                                        {tab.charAt(0).toUpperCase() + tab.slice(1)}
                                    </button>
                                ))}
                            </div>

                            {activeTab === 'about' && (
                                <div>
                                    <p className="text-sm text-muted-foreground">{doctor.bio}</p>
                                    <p className="mt-2 text-sm text-muted-foreground">
                                        <strong>License:</strong> {doctor.license_number}
                                    </p>
                                </div>
                            )}

                            {activeTab === 'schedule' && (
                                <div>
                                    <h3 className="mb-2 font-medium">Weekly Schedule</h3>
                                    <div className="space-y-1">
                                        {dayNames.map((day, i) => {
                                            const sched = doctor.schedules.find((s) => s.day_of_week === i);
                                            return (
                                                <div key={day} className="flex items-center justify-between py-1 text-sm">
                                                    <span className="w-10 font-medium">{day}</span>
                                                    {sched ? (
                                                        <span className="text-muted-foreground">
                                                            {sched.start_time.slice(0, 5)} - {sched.end_time.slice(0, 5)}
                                                        </span>
                                                    ) : (
                                                        <span className="text-muted-foreground/50">Unavailable</span>
                                                    )}
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            )}

                            {activeTab === 'reviews' && (
                                <div className="space-y-4">
                                    {doctor.ratings.length === 0 && (
                                        <p className="text-sm text-muted-foreground">No reviews yet.</p>
                                    )}
                                    {doctor.ratings.map((r) => (
                                        <div key={r.id} className="border-b pb-3 last:border-0">
                                            <div className="flex items-center gap-2 mb-1">
                                                <span className="text-sm font-medium">{r.patient.user.name}</span>
                                                <div className="flex">
                                                    {Array.from({ length: r.rating }).map((_, i) => (
                                                        <Star key={i} className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                                                    ))}
                                                </div>
                                            </div>
                                            {r.review && <p className="text-sm text-muted-foreground">{r.review}</p>}
                                        </div>
                                    ))}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div>

                <div>
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-lg">Book Appointment</CardTitle>
                            <p className="text-sm text-muted-foreground">₹{doctor.consultation_fee} consultation fee</p>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                <Button
                                    className="w-full"
                                    variant="default"
                                    disabled={paying}
                                    onClick={handleInstantPay}
                                >
                                    {paying ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Video className="mr-2 h-4 w-4" />}
                                    Start Instant Consultation — ₹{finalAmount}
                                </Button>

                                <div className="relative">
                                    <div className="absolute inset-0 flex items-center">
                                        <span className="w-full border-t" />
                                    </div>
                                    <div className="relative flex justify-center text-xs uppercase">
                                        <span className="bg-card px-2 text-muted-foreground">Or schedule for later</span>
                                    </div>
                                </div>

                                <div>
                                    <Label htmlFor="date">Date</Label>
                                    <Input
                                        id="date"
                                        type="date"
                                        min={new Date().toISOString().split('T')[0]}
                                        value={selectedDate}
                                        onChange={(e) => {
                                            setSelectedDate(e.target.value);
                                            setData('appointment_date', e.target.value);
                                        }}
                                    />
                                </div>

                                {selectedDate && slots.length > 0 && (
                                    <div>
                                        <Label>Available Time Slots</Label>
                                        <div className="mt-2 grid grid-cols-2 gap-2">
                                            {slots.map((slot) => (
                                                <Button
                                                    key={slot.start}
                                                    type="button"
                                                    variant={selectedTime === slot.start ? 'default' : 'outline'}
                                                    size="sm"
                                                    onClick={() => {
                                                        setSelectedTime(slot.start);
                                                        setData({ ...data, start_time: slot.start, end_time: slot.end });
                                                    }}
                                                >
                                                    <Clock className="mr-1 h-3 w-3" />
                                                    {slot.start}
                                                </Button>
                                            ))}
                                        </div>
                                    </div>
                                )}

                                {selectedDate && slots.length === 0 && (
                                    <p className="text-sm text-muted-foreground">No slots available on this date.</p>
                                )}

                                <div>
                                    <Label htmlFor="type">Type</Label>
                                    <select
                                        id="type"
                                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                                        value={data.type}
                                        onChange={(e) => setData('type', e.target.value as 'virtual')}
                                    >
                                        <option value="virtual">Virtual</option>
                                    </select>
                                </div>

                                <div>
                                    <Label htmlFor="notes">Notes (optional)</Label>
                                    <Textarea
                                        id="notes"
                                        placeholder="Any symptoms or concerns..."
                                        value={data.notes}
                                        onChange={(e) => setData('notes', e.target.value)}
                                    />
                                </div>

                                <div className="space-y-4 pt-4 border-t">
                                    <div>
                                        <Label htmlFor="promo">Promo Code</Label>
                                        <div className="flex gap-2 mt-1">
                                            <Input
                                                id="promo"
                                                placeholder="Enter code"
                                                value={promoCode}
                                                onChange={(e) => setPromoCode(e.target.value)}
                                                disabled={!!discountInfo}
                                            />
                                            <Button
                                                type="button"
                                                variant={discountInfo ? "destructive" : "secondary"}
                                                onClick={() => {
                                                    if (discountInfo) {
                                                        setDiscountInfo(null);
                                                        setPromoCode('');
                                                        setData('coupon_id', null);
                                                    } else {
                                                        applyPromo();
                                                    }
                                                }}
                                            >
                                                {discountInfo ? "Remove" : "Apply"}
                                            </Button>
                                        </div>
                                        {promoError && <p className="text-xs text-destructive mt-1">{promoError}</p>}
                                        {discountInfo && (
                                            <p className="text-xs text-green-600 mt-1">
                                                Code '{discountInfo.code}' applied: -₹{discountInfo.discount}
                                            </p>
                                        )}
                                    </div>
                                    <div className="flex justify-between items-center font-medium">
                                        <span>Total:</span>
                                        <span>₹{finalAmount}</span>
                                    </div>
                                </div>

                                {Object.keys(allErrors).length > 0 && (
                                    <div className="bg-destructive/10 p-3 rounded-md space-y-2 border border-destructive/20">
                                        <div className="flex items-center gap-2 text-destructive">
                                            <AlertCircle className="h-4 w-4" />
                                            <span className="text-sm font-semibold">Booking Error</span>
                                        </div>
                                        <div className="space-y-1">
                                            {Object.entries(allErrors).map(([key, err]) => (
                                                <p key={key} className="text-xs text-destructive font-medium pl-6">
                                                    {String(err)}
                                                </p>
                                            ))}
                                        </div>
                                    </div>
                                )}

                                <Button
                                    className="w-full"
                                    disabled={processing || paying || !selectedTime}
                                    onClick={handlePayAndBook}
                                >
                                    {paying ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Calendar className="mr-2 h-4 w-4" />}
                                    {paying ? 'Processing...' : `Book — ₹${finalAmount}`}
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
