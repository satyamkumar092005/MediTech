import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, router } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, Clock, MapPin, Video, XCircle } from 'lucide-react';
import Pagination from '@/Components/Pagination';

interface Appointment {
    id: number;
    doctor: { user: { name: string }; specialization: { name: string } };
    appointment_date: string;
    start_time: string;
    end_time: string;
    type: 'virtual';
    status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
    notes: string | null;
    meeting_link: string | null;
    prescription: { id: number } | null;
}

const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
    confirmed: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
    completed: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
    cancelled: 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400',
};

export default function Appointments({ appointments }: { appointments: { data: Appointment[]; links: any[]; meta: any } }) {
    const handleCancel = (id: number) => {
        if (confirm('Cancel this appointment?')) {
            router.patch(`/patient/appointments/${id}/cancel`);
        }
    };

    return (
        <AuthenticatedLayout header={<h2 className="text-xl font-semibold">My Appointments</h2>}>
            <Head title="My Appointments" />

            <div className="space-y-4">
                {appointments.data.length === 0 && (
                    <Card>
                        <CardContent className="py-12 text-center">
                            <p className="text-muted-foreground">No appointments yet.</p>
                            <Button className="mt-4" onClick={() => router.visit('/patient/doctors')}>
                                Book an Appointment
                            </Button>
                        </CardContent>
                    </Card>
                )}
                {appointments.data.map((apt) => (
                    <Card key={apt.id}>
                        <CardContent className="pt-6">
                            <div className="flex items-start justify-between">
                                <div>
                                    <div className="flex items-center gap-2 mb-1">
                                        <h3 className="font-semibold">{apt.doctor.user.name}</h3>
                                        <Badge className={statusColors[apt.status]}>
                                            {apt.status.charAt(0).toUpperCase() + apt.status.slice(1)}
                                        </Badge>
                                    </div>
                                    <p className="text-sm text-muted-foreground mb-2">
                                        {apt.doctor.specialization.name}
                                    </p>
                                    <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                                        <span className="flex items-center gap-1">
                                            <Calendar className="h-4 w-4" />
                                            {apt.appointment_date}
                                        </span>
                                        <span className="flex items-center gap-1">
                                            <Clock className="h-4 w-4" />
                                            {apt.start_time.slice(0, 5)} - {apt.end_time.slice(0, 5)}
                                        </span>
                                        <span className="flex items-center gap-1">
                                            {apt.type === 'virtual' ? <Video className="h-4 w-4" /> : <MapPin className="h-4 w-4" />}
                                            Virtual
                                        </span>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Link href={`/patient/appointments/${apt.id}`}>
                                        <Button variant="outline" size="sm">View</Button>
                                    </Link>
                                    {apt.status === 'pending' && (
                                        <Button variant="destructive" size="sm" onClick={() => handleCancel(apt.id)}>
                                            <XCircle className="h-4 w-4" />
                                        </Button>
                                    )}
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}
                <Pagination links={appointments.links} meta={appointments.meta} />
            </div>
        </AuthenticatedLayout>
    );
}
