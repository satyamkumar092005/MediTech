import { Head, router } from '@inertiajs/react';
import { Button } from '@/components/ui/button';
import { Mic, MicOff, Video, VideoOff, PhoneOff, Volume2, Loader2 } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { AgentSession, AgentMicrophone, AgentPlayer } from '@deepgram/agents';

interface Appointment {
    id: number;
    doctor: {
        user: { name: string; email: string; avatar?: string };
        specialization: { name: string };
        consultation_fee: number;
    };
    appointment_date: string;
    start_time: string;
    status: string;
}

export default function VideoCall({ appointment }: { appointment: Appointment }) {
    const videoRef = useRef<HTMLVideoElement>(null);
    const [camOn, setCamOn] = useState(true);
    const [micOn, setMicOn] = useState(true);
    const [aiStatus, setAiStatus] = useState<string>('connecting');
    const [error, setError] = useState<string | null>(null);

    const sessionRef = useRef<AgentSession | null>(null);
    const playerRef = useRef<AgentPlayer | null>(null);
    const micRef = useRef<AgentMicrophone | null>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const endedRef = useRef(false);
    const conversationRef = useRef<{ role: string; content: string }[]>([]);

    useEffect(() => {
        endedRef.current = false;

        const init = async () => {
            try {
                navigator.mediaDevices.getUserMedia({ video: true })
                    .then((s) => {
                        if (endedRef.current) { s.getTracks().forEach(t => t.stop()); return; }
                        streamRef.current = s;
                        if (videoRef.current) videoRef.current.srcObject = s;
                    })
                    .catch(() => setCamOn(false));

                const settingsRes = await fetch(`/patient/deepgram/settings/${appointment.id}`);
                if (!settingsRes.ok) throw new Error('Failed to load agent settings');
                const settings = await settingsRes.json();

                const session = new AgentSession({
                    auth: {
                        tokenFactory: () =>
                            fetch('/patient/deepgram/token', { method: 'POST' }).then((r) => {
                                if (!r.ok) throw new Error('Token fetch failed');
                                return r.text();
                            }),
                    },
                    agent: settings.agent,
                    audio: settings.audio,
                });

                const player = new AgentPlayer();
                const mic = new AgentMicrophone(
                    (data) => session.sendAudio(data),
                    { sampleRate: 16000 },
                );

                session.on('welcome', () => setAiStatus('connected'));
                session.on('settings-applied', () => {
                    setAiStatus('listening');
                    mic.start();
                });
                session.on('audio', (chunk) => player.queue(chunk));
                session.on('user-started-speaking', () => {
                    player.interrupt();
                    setAiStatus('listening');
                });
                session.on('agent-started-speaking', () => setAiStatus('speaking'));
                session.on('agent-audio-done', () => setAiStatus('listening'));
                session.on('conversation-text', (msg) => {
                    conversationRef.current.push({ role: msg.role, content: msg.content });
                });
                session.on('error', (msg) => {
                    console.error('Agent error:', msg);
                    setError('Agent error occurred');
                });
                session.on('disconnected', (reason) => {
                    if (!endedRef.current) {
                        setAiStatus('disconnected');
                        setError(`Disconnected: ${reason}`);
                    }
                });

                sessionRef.current = session;
                playerRef.current = player;
                micRef.current = mic;

                await session.connect();
            } catch (e: any) {
                console.error('Session init failed:', e);
                setError(e.message || 'Failed to connect');
                setAiStatus('error');
            }
        };

        init();

        return () => {
            endedRef.current = true;
            micRef.current?.stop();
            playerRef.current?.dispose();
            sessionRef.current?.disconnect();
            streamRef.current?.getTracks().forEach((t) => t.stop());
        };
    }, []);

    const toggleMic = () => {
        const m = micRef.current;
        if (m) {
            if (micOn) m.mute();
            else m.unmute();
        }
        setMicOn(!micOn);
    };

    const toggleCam = () => {
        streamRef.current?.getVideoTracks().forEach((t) => { t.enabled = !t.enabled; });
        setCamOn((c) => !c);
    };

    const endCall = async () => {
        endedRef.current = true;
        micRef.current?.stop();
        playerRef.current?.dispose();
        sessionRef.current?.disconnect();
        streamRef.current?.getTracks().forEach((t) => t.stop());

        const transcript = conversationRef.current
            .map((m) => `${m.role === 'user' ? 'Patient' : 'Doctor'}: ${m.content}`)
            .join('\n');

        try {
            await fetch(`/patient/appointments/${appointment.id}/summary`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ?? '' },
                body: JSON.stringify({ transcript }),
            });
        } catch { /* non-critical */ }

        router.visit(`/patient/appointments/${appointment.id}`);
    };

    const doctorName = appointment.doctor.user.name.replace('Dr. ', '');
    const lastName = doctorName.split(' ').slice(-1)[0];

    const statusLabel: Record<string, string> = {
        connecting: 'Connecting to AI doctor...',
        connected: 'Initializing...',
        listening: 'Listening...',
        speaking: 'AI doctor is speaking...',
        disconnected: 'Disconnected',
        error: 'Connection error',
    };

    return (
        <div className="flex flex-col h-screen bg-black">
            <Head title="Live Consultation" />
            <div className="flex-1 relative">
                <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                        <div className="w-48 h-48 mx-auto rounded-full overflow-hidden border-4 border-white/20 mb-4">
                            {appointment.doctor.user.avatar ? (
                                <img src={appointment.doctor.user.avatar} alt={appointment.doctor.user.name} className="w-full h-full object-cover" />
                            ) : (
                                <div className="w-full h-full flex items-center justify-center bg-primary/20 text-5xl font-bold text-white">
                                    {lastName[0]}
                                </div>
                            )}
                        </div>
                        <h2 className="text-2xl font-bold text-white">{appointment.doctor.user.name}</h2>
                        <p className="text-white/60 mb-4">{appointment.doctor.specialization.name}</p>

                        <div className="flex items-center justify-center gap-2 text-sm">
                            {aiStatus === 'speaking' && <Volume2 className="h-4 w-4 text-green-400 animate-pulse" />}
                            {aiStatus === 'listening' && <div className="h-2 w-2 rounded-full bg-green-400 animate-pulse" />}
                            {aiStatus === 'connecting' && <Loader2 className="h-4 w-4 text-yellow-400 animate-spin" />}
                            <span className={cn(
                                'text-white/80',
                                aiStatus === 'error' && 'text-red-400',
                                aiStatus === 'disconnected' && 'text-red-400',
                            )}>
                                {statusLabel[aiStatus] || aiStatus}
                            </span>
                        </div>

                        {aiStatus === 'listening' && (
                            <div className="flex items-center justify-center gap-1 mt-4">
                                {[1, 2, 3].map((i) => (
                                    <div
                                        key={i}
                                        className="w-1.5 h-1.5 rounded-full bg-green-400 animate-bounce"
                                        style={{ animationDelay: `${i * 0.15}s` }}
                                    />
                                ))}
                            </div>
                        )}

                        {error && <p className="text-red-400 text-sm mt-2">{error}</p>}
                    </div>
                </div>

                <div className="absolute bottom-4 right-4 w-48 h-36 rounded-xl overflow-hidden border-2 border-white/20 bg-gray-800 shadow-lg">
                    {camOn && streamRef.current ? (
                        <video ref={videoRef} autoPlay muted playsInline className="w-full h-full object-cover" />
                    ) : (
                        <div className="w-full h-full flex items-center justify-center text-white/40">
                            <VideoOff className="h-8 w-8" />
                        </div>
                    )}
                </div>
            </div>

            <div className="h-24 flex items-center justify-center gap-4 bg-black/80 border-t border-white/10">
                <Button
                    variant={micOn ? 'secondary' : 'destructive'}
                    size="icon"
                    className="rounded-full h-14 w-14"
                    onClick={toggleMic}
                >
                    {micOn ? <Mic className="h-6 w-6" /> : <MicOff className="h-6 w-6" />}
                </Button>
                <Button
                    variant="destructive"
                    size="icon"
                    className="rounded-full h-14 w-14"
                    onClick={endCall}
                >
                    <PhoneOff className="h-6 w-6" />
                </Button>
                <Button
                    variant={camOn ? 'secondary' : 'destructive'}
                    size="icon"
                    className="rounded-full h-14 w-14"
                    onClick={toggleCam}
                >
                    {camOn ? <Video className="h-6 w-6" /> : <VideoOff className="h-6 w-6" />}
                </Button>
            </div>
        </div>
    );
}
