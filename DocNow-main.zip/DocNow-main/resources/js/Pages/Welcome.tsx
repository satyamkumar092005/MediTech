import { PageProps } from '@/types';
import { Head, Link } from '@inertiajs/react';
import { Button } from '@/components/ui/button';
import { Video, Calendar, ShieldCheck, Stethoscope, Sparkles, ArrowRight, Activity, Cpu } from 'lucide-react';

export default function Welcome({ auth }: PageProps) {
    return (
        <>
            <Head title="DocNow - Next-Gen Telemedicine" />
            <div className="relative min-h-screen bg-slate-950 text-slate-50 selection:bg-blue-500/30 overflow-hidden font-sans">
                
                {/* Background Ambient Glows */}
                <div className="absolute top-0 inset-x-0 h-screen overflow-hidden -z-10 pointer-events-none">
                    <div className="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] rounded-full bg-blue-600/20 blur-[120px]" />
                    <div className="absolute top-[30%] -right-[10%] w-[40%] h-[40%] rounded-full bg-cyan-500/10 blur-[120px]" />
                    <div className="absolute -bottom-[20%] left-[20%] w-[60%] h-[50%] rounded-full bg-indigo-600/10 blur-[120px]" />
                    {/* Grid Pattern */}
                    <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-20" />
                </div>

                {/* Navbar */}
                <nav className="sticky top-0 z-50 border-b border-white/10 bg-slate-950/60 backdrop-blur-xl">
                    <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
                        <div className="flex items-center gap-3">
                            <div className="flex size-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-cyan-400 shadow-[0_0_15px_rgba(37,99,235,0.5)]">
                                <Stethoscope className="size-6 text-white" />
                            </div>
                            <span className="text-2xl font-bold tracking-tight text-white">Doc<span className="text-blue-400">Now</span></span>
                        </div>
                        <div className="flex items-center gap-4">
                            {auth.user ? (
                                <Link href={route('dashboard')}>
                                    <Button className="bg-white/10 text-white hover:bg-white/20 border border-white/10 backdrop-blur-sm">
                                        Dashboard <ArrowRight className="ml-2 h-4 w-4" />
                                    </Button>
                                </Link>
                            ) : (
                                <>
                                    <Link href={route('login')} className="hidden sm:block">
                                        <Button variant="ghost" className="text-slate-300 hover:text-white hover:bg-white/5">
                                            Log in
                                        </Button>
                                    </Link>
                                    <Link href={route('register')}>
                                        <Button className="bg-blue-600 text-white hover:bg-blue-500 shadow-[0_0_15px_rgba(37,99,235,0.4)]">
                                            Get Started
                                        </Button>
                                    </Link>
                                </>
                            )}
                        </div>
                    </div>
                </nav>

                {/* Hero Section */}
                <section className="relative px-6 pt-24 pb-32 sm:pt-32 sm:pb-40 lg:px-8">
                    <div className="mx-auto max-w-4xl text-center">
                        <div className="inline-flex items-center gap-2 rounded-full border border-blue-500/30 bg-blue-500/10 px-4 py-1.5 mb-8 text-sm font-medium text-blue-300 shadow-[0_0_10px_rgba(59,130,246,0.2)]">
                            <Sparkles className="size-4" />
                            <span>Powered by Gemini AI & Deepgram</span>
                        </div>
                        
                        <h1 className="text-5xl font-extrabold tracking-tight sm:text-7xl mb-8">
                            <span className="block text-white">Healthcare,</span>
                            <span className="block mt-2 bg-gradient-to-r from-blue-400 via-cyan-300 to-indigo-400 bg-clip-text text-transparent">
                                Redefined for the Future.
                            </span>
                        </h1>
                        
                        <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-slate-400">
                            Connect with elite medical professionals instantly. Experience crystal-clear HD video consultations, real-time AI symptom analysis, and seamless digital prescriptions.
                        </p>
                        
                        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
                            <Link href={auth.user ? route('patient.doctors.index') : route('register')} className="w-full sm:w-auto">
                                <Button size="lg" className="w-full sm:w-auto h-14 px-8 bg-blue-600 hover:bg-blue-500 text-white text-lg shadow-[0_0_20px_rgba(37,99,235,0.4)] border border-blue-400/20">
                                    <Video className="mr-2 size-5" /> Start Instant Consult
                                </Button>
                            </Link>
                            <Link href={route('login')} className="w-full sm:w-auto">
                                <Button size="lg" variant="outline" className="w-full sm:w-auto h-14 px-8 bg-slate-900/50 hover:bg-slate-800 text-slate-200 border-slate-700 backdrop-blur-sm text-lg">
                                    <Calendar className="mr-2 size-5" /> Book an Appointment
                                </Button>
                            </Link>
                        </div>
                    </div>
                </section>

                {/* Features Benthos */}
                <section className="relative py-24 border-t border-white/5 bg-slate-950/50 backdrop-blur-3xl">
                    <div className="mx-auto max-w-7xl px-6 lg:px-8">
                        <div className="mb-16 max-w-2xl">
                            <h2 className="text-blue-400 font-semibold tracking-wide uppercase text-sm">Next-Generation Platform</h2>
                            <p className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">
                                Everything you need for remote care.
                            </p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            {/* Feature 1 */}
                            <div className="group relative rounded-2xl border border-white/10 bg-slate-900/50 p-8 hover:bg-slate-800/50 transition-all duration-300 hover:-translate-y-1">
                                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-blue-600/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                                <div className="relative z-10">
                                    <div className="mb-6 inline-flex size-12 items-center justify-center rounded-xl bg-blue-500/20 border border-blue-500/30 text-blue-400 group-hover:scale-110 transition-transform">
                                        <Activity className="size-6" />
                                    </div>
                                    <h3 className="mb-3 text-xl font-bold text-white">HD Video & Audio</h3>
                                    <p className="text-slate-400 leading-relaxed">
                                        Zero-latency consultations directly in your browser. Powered by advanced WebRTC for reliable, secure patient-doctor connections.
                                    </p>
                                </div>
                            </div>

                            {/* Feature 2 */}
                            <div className="group relative rounded-2xl border border-white/10 bg-slate-900/50 p-8 hover:bg-slate-800/50 transition-all duration-300 hover:-translate-y-1">
                                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-cyan-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                                <div className="relative z-10">
                                    <div className="mb-6 inline-flex size-12 items-center justify-center rounded-xl bg-cyan-500/20 border border-cyan-500/30 text-cyan-400 group-hover:scale-110 transition-transform">
                                        <Cpu className="size-6" />
                                    </div>
                                    <h3 className="mb-3 text-xl font-bold text-white">AI Symptom Checker</h3>
                                    <p className="text-slate-400 leading-relaxed">
                                        Describe your condition to our Gemini-powered AI assistant and get an instant medical abstract before you even speak to a doctor.
                                    </p>
                                </div>
                            </div>

                            {/* Feature 3 */}
                            <div className="group relative rounded-2xl border border-white/10 bg-slate-900/50 p-8 hover:bg-slate-800/50 transition-all duration-300 hover:-translate-y-1">
                                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-indigo-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                                <div className="relative z-10">
                                    <div className="mb-6 inline-flex size-12 items-center justify-center rounded-xl bg-indigo-500/20 border border-indigo-500/30 text-indigo-400 group-hover:scale-110 transition-transform">
                                        <ShieldCheck className="size-6" />
                                    </div>
                                    <h3 className="mb-3 text-xl font-bold text-white">Secure Payments</h3>
                                    <p className="text-slate-400 leading-relaxed">
                                        Integrated with Razorpay for instant, bank-grade secure fee transactions. Plus, support for promotional coupons.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                {/* Footer */}
                <footer className="border-t border-white/10 bg-slate-950 py-12">
                    <div className="mx-auto max-w-7xl px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-6">
                        <div className="flex items-center gap-2 opacity-80 hover:opacity-100 transition-opacity">
                            <Stethoscope className="size-5 text-blue-400" />
                            <span className="font-semibold text-white tracking-wide">DocNow</span>
                        </div>
                        <div className="flex gap-6 text-sm text-slate-500">
                            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
                            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
                            <a href="#" className="hover:text-white transition-colors">Contact Support</a>
                        </div>
                        <p className="text-sm text-slate-500">
                            &copy; {new Date().getFullYear()} DocNow Inc. All rights reserved.
                        </p>
                    </div>
                </footer>
            </div>
        </>
    );
}
