import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, UserCheck, Calendar, CheckCircle2, IndianRupee, ArrowRight } from 'lucide-react';

interface Appointment {
    id: number;
    doctor: { user: { name: string } };
    patient: { user: { name: string } };
    appointment_date: string;
    status: string;
}

interface Stats {
    totalUsers: number;
    totalDoctors: number;
    totalAppointments: number;
    completedAppointments: number;
    estimatedRevenue: number;
}

const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800',
    confirmed: 'bg-blue-100 text-blue-800',
    completed: 'bg-green-100 text-green-800',
    cancelled: 'bg-gray-100 text-gray-800',
};

export default function AdminDashboard({ stats, recentAppointments }: { stats: Stats; recentAppointments: Appointment[] }) {
    return (
        <AuthenticatedLayout
            header={<h2 className="text-xl font-semibold">Admin Dashboard</h2>}
        >
            <Head title="Dashboard" />

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                        <IndianRupee className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">₹{stats.estimatedRevenue.toLocaleString()}</div>
                        <p className="text-xs text-muted-foreground mt-1">Confirmed & Completed</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                        <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{stats.totalUsers}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Doctors</CardTitle>
                        <UserCheck className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{stats.totalDoctors}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Appointments</CardTitle>
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{stats.totalAppointments}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Completed</CardTitle>
                        <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{stats.completedAppointments}</div>
                    </CardContent>
                </Card>
            </div>

            <div className="mt-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">Recent Appointments</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {recentAppointments.length === 0 ? (
                            <p className="text-sm text-muted-foreground">No appointments yet.</p>
                        ) : (
                            <div className="space-y-3">
                                {recentAppointments.map((a) => (
                                    <div key={a.id} className="flex items-center justify-between rounded-lg border p-3">
                                        <div>
                                            <p className="text-sm font-medium">{a.doctor.user.name} → {a.patient.user.name}</p>
                                            <p className="text-xs text-muted-foreground">{a.appointment_date}</p>
                                        </div>
                                        <Badge className={statusColors[a.status]}>{a.status}</Badge>
                                    </div>
                                ))}
                            </div>
                        )}
                        <Link href="/admin/appointments" className="mt-3 flex items-center gap-1 text-sm text-primary hover:underline">
                            View all <ArrowRight className="h-3 w-3" />
                        </Link>
                    </CardContent>
                </Card>
            </div>
        </AuthenticatedLayout>
    );
}
