import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, Star, Users, ArrowRight, Video } from 'lucide-react';

interface Appointment {
    id: number;
    patient: { user: { name: string } };
    appointment_date: string;
    start_time: string;
    status: string;
}

interface Prescription {
    id: number;
    appointment: { patient: { user: { name: string } } };
    created_at: string;
}

interface Stats {
    todayAppointments: number;
    totalPatients: number;
    averageRating: number | null;
    activeSlots: number;
    upcomingAppointments: Appointment[];
    recentPrescriptions: Prescription[];
}

export default function DoctorDashboard({ todayAppointments, totalPatients, averageRating, activeSlots, upcomingAppointments, recentPrescriptions }: Stats) {
    return (
        <AuthenticatedLayout
            header={<h2 className="text-xl font-semibold">Doctor Dashboard</h2>}
        >
            <Head title="Dashboard" />

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Today's Appointments</CardTitle>
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{todayAppointments}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
                        <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{totalPatients}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
                        <Star className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{averageRating ? averageRating.toFixed(1) : '-'}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Active Slots</CardTitle>
                        <Clock className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{activeSlots}</div>
                    </CardContent>
                </Card>
            </div>

            <div className="mt-6 grid gap-6 lg:grid-cols-2">
                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">Upcoming Appointments</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {upcomingAppointments.length === 0 ? (
                            <p className="text-sm text-muted-foreground">No upcoming appointments.</p>
                        ) : (
                            <div className="space-y-3">
                                {upcomingAppointments.map((a) => (
                                    <div key={a.id} className="flex items-center justify-between rounded-lg border p-3">
                                        <div>
                                            <p className="text-sm font-medium">{a.patient.user.name}</p>
                                            <p className="text-xs text-muted-foreground">{a.appointment_date} at {a.start_time?.slice(0,5)}</p>
                                        </div>
                                        <Badge variant={a.status === 'confirmed' ? 'default' : 'secondary'}>{a.status}</Badge>
                                    </div>
                                ))}
                            </div>
                        )}
                        <Link href="/doctor/appointments" className="mt-3 flex items-center gap-1 text-sm text-primary hover:underline">
                            View all <ArrowRight className="h-3 w-3" />
                        </Link>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">Recent Prescriptions</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {recentPrescriptions.length === 0 ? (
                            <p className="text-sm text-muted-foreground">No prescriptions yet.</p>
                        ) : (
                            <div className="space-y-3">
                                {recentPrescriptions.map((p) => (
                                    <div key={p.id} className="flex items-center justify-between rounded-lg border p-3">
                                        <p className="text-sm font-medium">{p.appointment?.patient?.user?.name}</p>
                                        <span className="text-xs text-muted-foreground">{new Date(p.created_at).toLocaleDateString()}</span>
                                    </div>
                                ))}
                            </div>
                        )}
                        <Link href="/doctor/appointments" className="mt-3 flex items-center gap-1 text-sm text-primary hover:underline">
                            View appointments <ArrowRight className="h-3 w-3" />
                        </Link>
                    </CardContent>
                </Card>
            </div>
        </AuthenticatedLayout>
    );
}
