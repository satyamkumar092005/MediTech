import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Pill, Star, UserCheck, ArrowRight, Video } from 'lucide-react';
import { SymptomChecker } from '@/Components/SymptomChecker';

interface Appointment {
    id: number;
    doctor: { user: { name: string }; specialization: { name: string } };
    appointment_date: string;
    start_time: string;
    status: string;
}

interface PrescriptionItem {
    id: number;
    medicine_name: string;
    dosage: string;
    frequency: string;
    duration: string;
}

interface Prescription {
    id: number;
    doctor: { user: { name: string } };
    items: PrescriptionItem[];
    created_at: string;
}

interface Stats {
    upcomingAppointments: number;
    totalPrescriptions: number;
    availableDoctors: number;
    myRatings: number;
    recentAppointments: Appointment[];
    recentPrescriptions: Prescription[];
}

const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800',
    confirmed: 'bg-blue-100 text-blue-800',
    completed: 'bg-green-100 text-green-800',
    cancelled: 'bg-gray-100 text-gray-800',
};

export default function PatientDashboard({ upcomingAppointments, totalPrescriptions, availableDoctors, myRatings, recentAppointments, recentPrescriptions }: Stats) {
    return (
        <AuthenticatedLayout
            header={<h2 className="text-xl font-semibold">Patient Dashboard</h2>}
        >
            <Head title="Dashboard" />

            <div className="mb-6">
                <SymptomChecker />
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Upcoming Appointments</CardTitle>
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{upcomingAppointments}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Prescriptions</CardTitle>
                        <Pill className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{totalPrescriptions}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Doctors Available</CardTitle>
                        <UserCheck className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{availableDoctors}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">My Ratings</CardTitle>
                        <Star className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{myRatings}</div>
                    </CardContent>
                </Card>
            </div>

            <div className="mt-6 grid gap-6 lg:grid-cols-2">
                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">Recent Appointments</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {recentAppointments.length === 0 ? (
                            <p className="text-sm text-muted-foreground">No appointments yet.</p>
                        ) : (
                            <div className="space-y-3">
                                {recentAppointments.map((a) => (
                                    <Link key={a.id} href={`/patient/appointments/${a.id}`}>
                                        <div className="flex items-center justify-between rounded-lg border p-3 hover:bg-accent/50 transition-colors cursor-pointer">
                                            <div>
                                                <p className="text-sm font-medium">{a.doctor.user.name}</p>
                                                <p className="text-xs text-muted-foreground">{a.doctor.specialization.name} — {a.appointment_date}</p>
                                            </div>
                                            <Badge className={statusColors[a.status]}>{a.status}</Badge>
                                        </div>
                                    </Link>
                                ))}
                            </div>
                        )}
                        <Link href="/patient/appointments" className="mt-3 flex items-center gap-1 text-sm text-primary hover:underline">
                            View all <ArrowRight className="h-3 w-3" />
                        </Link>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">Recent Prescriptions</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {recentPrescriptions.length === 0 ? (
                            <p className="text-sm text-muted-foreground">No prescriptions yet.</p>
                        ) : (
                            <div className="space-y-3">
                                {recentPrescriptions.map((p) => (
                                    <Link key={p.id} href={`/patient/prescriptions/${p.id}`}>
                                        <div className="rounded-lg border p-3 hover:bg-accent/50 transition-colors cursor-pointer">
                                            <div className="flex justify-between">
                                                <p className="text-sm font-medium">Dr. {p.doctor.user.name}</p>
                                                <span className="text-xs text-muted-foreground">{new Date(p.created_at).toLocaleDateString()}</span>
                                            </div>
                                            <p className="text-xs text-muted-foreground mt-1">
                                                {p.items.slice(0, 2).map((i) => i.medicine_name).join(', ')}
                                                {p.items.length > 2 ? ` +${p.items.length - 2} more` : ''}
                                            </p>
                                        </div>
                                    </Link>
                                ))}
                            </div>
                        )}
                        <Link href="/patient/prescriptions" className="mt-3 flex items-center gap-1 text-sm text-primary hover:underline">
                            View all <ArrowRight className="h-3 w-3" />
                        </Link>
                    </CardContent>
                </Card>
            </div>
        </AuthenticatedLayout>
    );
}
