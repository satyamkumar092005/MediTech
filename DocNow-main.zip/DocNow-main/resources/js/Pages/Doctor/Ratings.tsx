import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Star, MessageSquare } from 'lucide-react';
import Pagination from '@/Components/Pagination';

interface Rating {
    id: number;
    rating: number;
    review: string | null;
    created_at: string;
    patient: { user: { name: string } };
    appointment: { appointment_date: string };
}

export default function Ratings({ ratings }: { ratings: { data: Rating[]; links: any[]; meta: any } }) {
    return (
        <AuthenticatedLayout header={<h2 className="text-xl font-semibold">My Ratings</h2>}>
            <Head title="My Ratings" />

            <div className="space-y-4">
                {ratings.data.length === 0 && (
                    <Card>
                        <CardContent className="py-12 text-center text-muted-foreground">
                            No ratings yet.
                        </CardContent>
                    </Card>
                )}
                {ratings.data.map((r) => (
                    <Card key={r.id}>
                        <CardContent className="pt-6">
                            <div className="flex items-start justify-between">
                                <div>
                                    <h3 className="font-semibold">{r.patient.user.name}</h3>
                                    <p className="text-xs text-muted-foreground">{r.appointment.appointment_date}</p>
                                </div>
                                <div className="flex">
                                    {Array.from({ length: r.rating }).map((_, i) => (
                                        <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                    ))}
                                </div>
                            </div>
                            {r.review && (
                                <div className="mt-3 flex gap-2 text-sm text-muted-foreground">
                                    <MessageSquare className="h-4 w-4 mt-0.5 shrink-0" />
                                    <p>{r.review}</p>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                ))}
                <Pagination links={ratings.links} meta={ratings.meta} />
            </div>
        </AuthenticatedLayout>
    );
}
