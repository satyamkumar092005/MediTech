import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, router } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Calendar, Clock, CheckCircle, Plus, Trash2, Pill } from 'lucide-react';
import { useState } from 'react';

interface PrescriptionItem {
    medicine_name: string;
    dosage: string;
    frequency: string;
    duration: string;
    instructions: string;
}

interface Appointment {
    id: number;
    patient: { user: { name: string; email: string } };
    appointment_date: string;
    start_time: string;
    end_time: string;
    type: string;
    status: string;
    notes: string | null;
    consultation_summary: string | null;
    prescription: {
        id: number;
        notes: string | null;
        follow_up_date: string | null;
        items: { id: number; medicine_name: string; dosage: string; frequency: string; duration: string; instructions: string | null }[];
    } | null;
}

export default function AppointmentDetail({ appointment }: { appointment: Appointment }) {
    const [items, setItems] = useState<PrescriptionItem[]>(
        appointment.prescription?.items.map((i) => ({
            medicine_name: i.medicine_name,
            dosage: i.dosage,
            frequency: i.frequency,
            duration: i.duration,
            instructions: i.instructions || '',
        })) || [{ medicine_name: '', dosage: '', frequency: '', duration: '', instructions: '' }]
    );

    const { data, setData, post, processing } = useForm({
        appointment_id: appointment.id,
        notes: appointment.prescription?.notes || '',
        follow_up_date: appointment.prescription?.follow_up_date || '',
        items: items,
    });

    const handleAddItem = () => {
        setItems([...items, { medicine_name: '', dosage: '', frequency: '', duration: '', instructions: '' }]);
    };

    const handleRemoveItem = (index: number) => {
        if (items.length > 1) {
            const updated = items.filter((_, i) => i !== index);
            setItems(updated);
            setData('items', updated as any);
        }
    };

    const handleItemChange = (index: number, field: keyof PrescriptionItem, value: string) => {
        const updated = items.map((item, i) => i === index ? { ...item, [field]: value } : item);
        setItems(updated);
        setData('items', updated as any);
    };

    const handleSubmitPrescription = () => {
        post('/doctor/prescriptions', {
            preserveScroll: true,
            onSuccess: () => router.reload(),
        });
    };

    return (
        <AuthenticatedLayout
            header={
                <div className="flex items-center gap-4">
                    <Button variant="ghost" size="icon" onClick={() => router.visit('/doctor/appointments')}>
                        <ArrowLeft className="h-4 w-4" />
                    </Button>
                    <h2 className="text-xl font-semibold">Appointment #{appointment.id}</h2>
                </div>
            }
        >
            <Head title="Appointment Details" />

            <div className="grid gap-6 lg:grid-cols-3">
                <div className="lg:col-span-2">
                    <Card>
                        <CardHeader>
                            <div className="flex items-start justify-between">
                                <div>
                                    <CardTitle>{appointment.patient.user.name}</CardTitle>
                                    <p className="text-sm text-muted-foreground">{appointment.patient.user.email}</p>
                                </div>
                                <Badge>{appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}</Badge>
                            </div>
                        </CardHeader>
                        <CardContent>
                            <div className="flex flex-wrap gap-4 text-sm mb-4">
                                <span className="flex items-center gap-1"><Calendar className="h-4 w-4" /> {appointment.appointment_date}</span>
                                <span className="flex items-center gap-1"><Clock className="h-4 w-4" /> {appointment.start_time.slice(0,5)} - {appointment.end_time.slice(0,5)}</span>
                            </div>
                            {appointment.notes && (
                                <div>
                                    <h4 className="text-sm font-medium mb-1">Patient Notes</h4>
                                    <p className="text-sm text-muted-foreground">{appointment.notes}</p>
                                </div>
                            )}
                            {appointment.consultation_summary && (
                                <div className="mt-4">
                                    <h4 className="text-sm font-medium mb-1">Consultation Summary</h4>
                                    <div className="rounded-lg border p-3 text-sm text-muted-foreground whitespace-pre-wrap">
                                        {appointment.consultation_summary}
                                    </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>

                    {appointment.status !== 'completed' && (
                        <Card className="mt-6">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Pill className="h-5 w-5" />
                                    Write Prescription
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {items.map((item, index) => (
                                        <div key={index} className="rounded-lg border p-4">
                                            <div className="flex items-center justify-between mb-3">
                                                <h4 className="text-sm font-medium">Medicine #{index + 1}</h4>
                                                {items.length > 1 && (
                                                    <Button variant="ghost" size="icon" onClick={() => handleRemoveItem(index)}>
                                                        <Trash2 className="h-4 w-4 text-destructive" />
                                                    </Button>
                                                )}
                                            </div>
                                            <div className="grid grid-cols-2 gap-3">
                                                <div>
                                                    <Label>Medicine Name</Label>
                                                    <Input value={item.medicine_name} onChange={(e) => handleItemChange(index, 'medicine_name', e.target.value)} />
                                                </div>
                                                <div>
                                                    <Label>Dosage</Label>
                                                    <Input value={item.dosage} onChange={(e) => handleItemChange(index, 'dosage', e.target.value)} placeholder="e.g., 500mg" />
                                                </div>
                                                <div>
                                                    <Label>Frequency</Label>
                                                    <Input value={item.frequency} onChange={(e) => handleItemChange(index, 'frequency', e.target.value)} placeholder="e.g., 3x daily" />
                                                </div>
                                                <div>
                                                    <Label>Duration</Label>
                                                    <Input value={item.duration} onChange={(e) => handleItemChange(index, 'duration', e.target.value)} placeholder="e.g., 7 days" />
                                                </div>
                                            </div>
                                            <div className="mt-3">
                                                <Label>Instructions</Label>
                                                <Input value={item.instructions} onChange={(e) => handleItemChange(index, 'instructions', e.target.value)} placeholder="e.g., After meals" />
                                            </div>
                                        </div>
                                    ))}

                                    <Button variant="outline" onClick={handleAddItem}>
                                        <Plus className="mr-2 h-4 w-4" /> Add Medicine
                                    </Button>

                                    <div>
                                        <Label>Prescription Notes</Label>
                                        <Textarea value={data.notes} onChange={(e) => setData('notes', e.target.value)} />
                                    </div>
                                    <div>
                                        <Label>Follow-up Date</Label>
                                        <Input type="date" value={data.follow_up_date} onChange={(e) => setData('follow_up_date', e.target.value)} />
                                    </div>

                                    <div className="flex gap-2">
                                        <Button onClick={handleSubmitPrescription} disabled={processing}>
                                            {appointment.prescription ? 'Update Prescription' : 'Save Prescription'}
                                        </Button>
                                        <Button variant="default" onClick={() => router.patch(`/doctor/appointments/${appointment.id}/complete`)}>
                                            <CheckCircle className="mr-2 h-4 w-4" /> Complete Appointment
                                        </Button>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {appointment.prescription && appointment.status === 'completed' && (
                        <Card className="mt-6">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2"><Pill className="h-5 w-5" /> Prescription</CardTitle>
                            </CardHeader>
                            <CardContent>
                                {appointment.prescription.items.map((item) => (
                                    <div key={item.id} className="mb-2 rounded-lg border p-3">
                                        <p className="font-medium">{item.medicine_name}</p>
                                        <p className="text-sm text-muted-foreground">{item.dosage} — {item.frequency} — {item.duration}</p>
                                        {item.instructions && <p className="text-xs text-muted-foreground mt-1">{item.instructions}</p>}
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    )}
                </div>

                <div>
                    {appointment.status === 'pending' && (
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-lg">Actions</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-2">
                                <Button className="w-full" variant="outline" onClick={() => router.patch(`/doctor/appointments/${appointment.id}/confirm`)}>Confirm Appointment</Button>
                                <Button className="w-full" variant="default" onClick={() => router.patch(`/doctor/appointments/${appointment.id}/complete`)}>
                                    <CheckCircle className="mr-2 h-4 w-4" /> Mark Completed
                                </Button>
                            </CardContent>
                        </Card>
                    )}
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
