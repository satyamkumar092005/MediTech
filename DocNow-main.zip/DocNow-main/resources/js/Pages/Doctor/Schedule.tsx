import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, router } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Trash2, Plus, Clock } from 'lucide-react';
import { useState } from 'react';

const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

interface ScheduleItem {
    id: number;
    day_of_week: number;
    start_time: string;
    end_time: string;
    slot_duration_minutes: number;
    is_active: boolean;
}

export default function Schedule({ schedules }: { schedules: ScheduleItem[] }) {
    const [dayOfWeek, setDayOfWeek] = useState('0');
    const [startTime, setStartTime] = useState('09:00');
    const [endTime, setEndTime] = useState('17:00');
    const [duration, setDuration] = useState('30');

    const handleAdd = () => {
        router.post('/doctor/schedule', {
            day_of_week: parseInt(dayOfWeek),
            start_time: startTime,
            end_time: endTime,
            slot_duration_minutes: parseInt(duration),
            is_active: true,
        }, {
            preserveScroll: true,
            onSuccess: () => {
                setStartTime('09:00');
                setEndTime('17:00');
            },
        });
    };

    const handleDelete = (id: number) => {
        if (confirm('Remove this schedule slot?')) {
            router.delete(`/doctor/schedule/${id}`);
        }
    };

    const grouped = dayNames.map((name, i) => ({
        day: i,
        name,
        slots: schedules.filter((s) => s.day_of_week === i),
    }));

    return (
        <AuthenticatedLayout header={<h2 className="text-xl font-semibold">My Schedule</h2>}>
            <Head title="My Schedule" />

            <div className="grid gap-6 lg:grid-cols-3">
                <Card className="lg:col-span-2">
                    <CardHeader>
                        <CardTitle>Weekly Schedule</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {grouped.map(({ day, name, slots }) => (
                            <div key={day} className="mb-4 last:mb-0">
                                <h3 className="text-sm font-medium mb-2">{name}</h3>
                                {slots.length === 0 ? (
                                    <p className="text-xs text-muted-foreground mb-2">No slots</p>
                                ) : (
                                    <div className="space-y-1 mb-2">
                                        {slots.map((slot) => (
                                            <div key={slot.id} className="flex items-center justify-between rounded-lg border p-2 text-sm">
                                                <span className="flex items-center gap-2">
                                                    <Clock className="h-3 w-3 text-muted-foreground" />
                                                    {slot.start_time.slice(0, 5)} - {slot.end_time.slice(0, 5)}
                                                    <Badge variant="outline" className="text-xs">{slot.slot_duration_minutes}min</Badge>
                                                </span>
                                                <Button variant="ghost" size="icon" onClick={() => handleDelete(slot.id)}>
                                                    <Trash2 className="h-3 w-3 text-destructive" />
                                                </Button>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        ))}
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">Add Slot</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            <div>
                                <Label>Day</Label>
                                <select
                                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                                    value={dayOfWeek}
                                    onChange={(e) => setDayOfWeek(e.target.value)}
                                >
                                    {dayNames.map((name, i) => (
                                        <option key={i} value={i}>{name}</option>
                                    ))}
                                </select>
                            </div>
                            <div>
                                <Label>Start Time</Label>
                                <Input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
                            </div>
                            <div>
                                <Label>End Time</Label>
                                <Input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
                            </div>
                            <div>
                                <Label>Slot Duration (min)</Label>
                                <Input type="number" min={15} max={120} step={15} value={duration} onChange={(e) => setDuration(e.target.value)} />
                            </div>
                            <Button className="w-full" onClick={handleAdd}>
                                <Plus className="mr-2 h-4 w-4" /> Add Slot
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </AuthenticatedLayout>
    );
}
