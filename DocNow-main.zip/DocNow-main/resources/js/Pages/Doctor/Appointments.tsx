import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, router } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, Clock, MapPin, Video, CheckCircle, FileText } from 'lucide-react';
import Pagination from '@/Components/Pagination';

interface Appointment {
    id: number;
    patient: { user: { name: string } };
    appointment_date: string;
    start_time: string;
    end_time: string;
    type: 'virtual';
    status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
    notes: string | null;
    prescription: { id: number } | null;
}

const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800',
    confirmed: 'bg-blue-100 text-blue-800',
    completed: 'bg-green-100 text-green-800',
    cancelled: 'bg-gray-100 text-gray-800',
};

export default function Appointments({ appointments }: { appointments: { data: Appointment[]; links: any[]; meta: any } }) {
    return (
        <AuthenticatedLayout header={<h2 className="text-xl font-semibold">Appointments</h2>}>
            <Head title="Appointments" />

            <div className="space-y-4">
                {appointments.data.length === 0 && (
                    <Card>
                        <CardContent className="py-12 text-center text-muted-foreground">
                            No appointments yet.
                        </CardContent>
                    </Card>
                )}
                {appointments.data.map((apt) => (
                    <Card key={apt.id}>
                        <CardContent className="pt-6">
                            <div className="flex items-start justify-between">
                                <div>
                                    <div className="flex items-center gap-2 mb-1">
                                        <h3 className="font-semibold">{apt.patient.user.name}</h3>
                                        <Badge className={statusColors[apt.status]}>
                                            {apt.status.charAt(0).toUpperCase() + apt.status.slice(1)}
                                        </Badge>
                                    </div>
                                    <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                                        <span className="flex items-center gap-1"><Calendar className="h-4 w-4" /> {apt.appointment_date}</span>
                                        <span className="flex items-center gap-1"><Clock className="h-4 w-4" /> {apt.start_time.slice(0,5)} - {apt.end_time.slice(0,5)}</span>
                                        <span className="flex items-center gap-1">
                                            {apt.type === 'virtual' ? <Video className="h-4 w-4" /> : <MapPin className="h-4 w-4" />}
                                            Virtual
                                        </span>
                                    </div>
                                    {apt.notes && <p className="mt-2 text-sm text-muted-foreground">{apt.notes}</p>}
                                </div>
                                <div className="flex items-center gap-2">
                                    <Button variant="outline" size="sm" onClick={() => router.visit(`/doctor/appointments/${apt.id}`)}>
                                        View
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}
                <Pagination links={appointments.links} meta={appointments.meta} />
            </div>
        </AuthenticatedLayout>
    );
}
