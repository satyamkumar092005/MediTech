import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, router } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Search, Droplets } from 'lucide-react';
import { useState } from 'react';
import Pagination from '@/Components/Pagination';

interface Patient {
    id: number;
    user: { name: string; email: string; phone?: string };
    blood_group: string | null;
    allergies: string | null;
    emergency_contact: string | null;
}

export default function Patients({ patients, filters }: { patients: { data: Patient[]; links: any[]; meta: any }; filters: { search?: string } }) {
    const [search, setSearch] = useState(filters?.search || '');

    const handleSearch = (value: string) => {
        setSearch(value);
        router.get('/doctor/patients', { search: value || undefined }, {
            preserveState: true,
            replace: true,
        });
    };

    return (
        <AuthenticatedLayout header={<h2 className="text-xl font-semibold">My Patients</h2>}>
            <Head title="My Patients" />

            <div className="mb-4">
                <div className="relative max-w-sm">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                        placeholder="Search patients..."
                        className="pl-9"
                        value={search}
                        onChange={(e) => handleSearch(e.target.value)}
                    />
                </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {patients.data.length === 0 && (
                    <Card className="col-span-full">
                        <CardContent className="py-12 text-center text-muted-foreground">
                            No patients found.
                        </CardContent>
                    </Card>
                )}
                {patients.data.map((patient) => (
                    <Card key={patient.id}>
                        <CardContent className="pt-6">
                            <div className="flex items-center gap-3 mb-3">
                                <Avatar>
                                    <AvatarFallback>
                                        {patient.user.name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2)}
                                    </AvatarFallback>
                                </Avatar>
                                <div>
                                    <h3 className="font-semibold">{patient.user.name}</h3>
                                    <p className="text-xs text-muted-foreground">{patient.user.email}</p>
                                </div>
                            </div>
                            <div className="space-y-1 text-sm">
                                {patient.blood_group && (
                                    <p className="flex items-center gap-2 text-muted-foreground">
                                        <Droplets className="h-3 w-3" /> Blood: {patient.blood_group}
                                    </p>
                                )}
                                {patient.allergies && (
                                    <p className="flex items-center gap-2 text-muted-foreground">
                                        <span className="text-destructive">⚠</span> Allergies: {patient.allergies}
                                    </p>
                                )}
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
            <Pagination links={patients.links} meta={patients.meta} />
        </AuthenticatedLayout>
    );
}
