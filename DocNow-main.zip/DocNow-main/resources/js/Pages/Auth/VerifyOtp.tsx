import { Head, useForm } from '@inertiajs/react';

export default function VerifyOtp({ email }: { email: string }) {
    const { data, setData, post, processing, errors } = useForm({
        email: email,
        otp: '',
    });

    const handleSubmit = () => {
        post(route('verification.otp.verify'));
    };

    const handleResend = () => {
        post(route('verification.otp.resend'));
    };

    return (
        <>
            <Head title="Verify Email" />
            <div className="min-h-screen flex flex-col items-center justify-center bg-[#121212] relative overflow-hidden w-full">
                <div className="relative z-10 w-full max-w-sm rounded-3xl bg-gradient-to-r from-[#ffffff10] to-[#121212] backdrop-blur-sm shadow-2xl p-8 flex flex-col items-center">
                    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap" rel="stylesheet" />
                    <h2 className="text-5xl mb-4 text-center text-white" style={{ fontFamily: "'Dancing Script', cursive", fontWeight: 700 }}>
                        DocNow
                    </h2>
                    <p className="text-gray-400 text-sm mb-6 text-center">
                        Enter the 6-digit code sent to<br />
                        <span className="text-white font-medium">{email}</span>
                    </p>

                    <div className="flex flex-col w-full gap-4">
                        <div className="w-full flex flex-col gap-3">
                            <input
                                placeholder="000000"
                                type="text"
                                maxLength={6}
                                value={data.otp}
                                className="w-full px-5 py-4 rounded-xl bg-white/10 text-white placeholder-gray-500 text-2xl text-center tracking-[12px] focus:outline-none focus:ring-2 focus:ring-gray-400 font-mono"
                                onChange={(e) => {
                                    const val = e.target.value.replace(/\D/g, '').slice(0, 6);
                                    setData('otp', val);
                                }}
                            />
                            {errors.otp && (
                                <div className="text-sm text-red-400 text-left">{errors.otp}</div>
                            )}
                        </div>

                        <div>
                            <button
                                onClick={handleSubmit}
                                disabled={processing || data.otp.length !== 6}
                                className="w-full bg-white/10 text-white font-medium px-5 py-3 rounded-full shadow hover:bg-white/20 transition mb-3 text-sm disabled:opacity-50"
                            >
                                {processing ? 'Verifying...' : 'Verify Email'}
                            </button>

                            <div className="text-center mt-4">
                                <button
                                    onClick={handleResend}
                                    disabled={processing}
                                    className="text-xs text-gray-400 hover:text-white underline"
                                >
                                    Resend code
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
