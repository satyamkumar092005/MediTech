import { Head, useForm } from '@inertiajs/react';
import { SignIn1 } from '@/components/ui/modern-stunning-sign-in';

export default function Login({
    status,
    canResetPassword,
}: {
    status?: string;
    canResetPassword: boolean;
}) {
    const { data, setData, post, processing, errors, reset } = useForm({
        email: '',
        password: '',
        remember: false as boolean,
    });

    const handleSubmit = () => {
        post(route('login'), {
            onFinish: () => reset('password'),
        });
    };

    return (
        <>
            <Head title="Log in" />
            <SignIn1
                email={data.email}
                password={data.password}
                error={errors.email || errors.password}
                processing={processing}
                canResetPassword={canResetPassword}
                status={status}
                onEmailChange={(value) => setData('email', value)}
                onPasswordChange={(value) => setData('password', value)}
                onSubmit={handleSubmit}
            />
        </>
    );
}
