import { Head, useForm } from '@inertiajs/react';
import { SignUp1 } from '@/components/ui/modern-stunning-sign-in';

export default function Register() {
    const { data, setData, post, processing, errors, reset } = useForm({
        name: '',
        email: '',
        password: '',
        password_confirmation: '',
    });

    const handleSubmit = () => {
        post(route('register'), {
            onFinish: () => reset('password', 'password_confirmation'),
        });
    };

    return (
        <>
            <Head title="Register" />
            <SignUp1
                name={data.name}
                email={data.email}
                password={data.password}
                passwordConfirmation={data.password_confirmation}
                error={errors.name || errors.email || errors.password || errors.password_confirmation}
                processing={processing}
                onNameChange={(value) => setData('name', value)}
                onEmailChange={(value) => setData('email', value)}
                onPasswordChange={(value) => setData('password', value)}
                onPasswordConfirmationChange={(value) => setData('password_confirmation', value)}
                onSubmit={handleSubmit}
            />
        </>
    );
}
