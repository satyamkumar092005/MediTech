import * as React from "react"

interface SignIn1Props {
  email: string
  password: string
  error?: string
  processing?: boolean
  onEmailChange: (value: string) => void
  onPasswordChange: (value: string) => void
  onSubmit: () => void
  canResetPassword?: boolean
  status?: string
}

const SignIn1 = ({
  email,
  password,
  error,
  processing,
  onEmailChange,
  onPasswordChange,
  onSubmit,
  canResetPassword,
  status,
}: SignIn1Props) => {
  const [localError, setLocalError] = React.useState("")

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  }

  const handleSignIn = () => {
    if (!email || !password) {
      setLocalError("Please enter both email and password.")
      return
    }
    if (!validateEmail(email)) {
      setLocalError("Please enter a valid email address.")
      return
    }
    setLocalError("")
    onSubmit()
  }

  const displayError = localError || error

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#121212] relative overflow-hidden w-full rounded-xl">
      <div className="relative z-10 w-full max-w-sm rounded-3xl bg-gradient-to-r from-[#ffffff10] to-[#121212] backdrop-blur-sm shadow-2xl p-8 flex flex-col items-center">
        <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap" rel="stylesheet" />
        <h2 className="text-5xl mb-8 text-center text-white" style={{ fontFamily: "'Dancing Script', cursive", fontWeight: 700 }}>
          DocNow
        </h2>

        {status && (
          <div className="w-full mb-4 text-sm font-medium text-green-400 text-center">
            {status}
          </div>
        )}

        <div className="flex flex-col w-full gap-4">
          <div className="w-full flex flex-col gap-3">
            <input
              placeholder="Email"
              type="email"
              value={email}
              className="w-full px-5 py-3 rounded-xl bg-white/10 text-white placeholder-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-gray-400"
              onChange={(e) => {
                setLocalError("")
                onEmailChange(e.target.value)
              }}
            />
            <input
              placeholder="Password"
              type="password"
              value={password}
              className="w-full px-5 py-3 rounded-xl bg-white/10 text-white placeholder-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-gray-400"
              onChange={(e) => {
                setLocalError("")
                onPasswordChange(e.target.value)
              }}
            />
            {canResetPassword && (
              <div className="text-right">
                <a
                  href={route("password.request")}
                  className="text-xs text-gray-400 hover:text-white underline"
                >
                  Forgot password?
                </a>
              </div>
            )}
            {displayError && (
              <div className="text-sm text-red-400 text-left">{displayError}</div>
            )}
          </div>
          <hr className="opacity-10" />
          <div>
            <button
              onClick={handleSignIn}
              disabled={processing}
              className="w-full bg-white/10 text-white font-medium px-5 py-3 rounded-full shadow hover:bg-white/20 transition mb-3 text-sm disabled:opacity-50"
            >
              {processing ? "Signing in..." : "Sign in"}
            </button>
            <a
              href={route("auth.google.redirect")}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-b from-[#232526] to-[#2d2e30] rounded-full px-5 py-3 font-medium text-white shadow hover:brightness-110 transition mb-2 text-sm"
            >
              <img
                src="https://www.svgrepo.com/show/475656/google-color.svg"
                alt="Google"
                className="w-5 h-5"
              />
              Continue with Google
            </a>
            <div className="w-full text-center mt-2">
              <span className="text-xs text-gray-400">
                Don&apos;t have an account?{" "}
                <a
                  href={route("register")}
                  className="underline text-white/80 hover:text-white"
                >
                  Sign up, it&apos;s free!
                </a>
              </span>
            </div>
          </div>
        </div>
      </div>
      <div className="relative z-10 mt-12 flex flex-col items-center text-center">
        <p className="text-gray-400 text-sm mb-2">
          Join <span className="font-medium text-white">thousands</span> of
          patients and doctors already using DocNow.
        </p>
        <div className="flex -space-x-2">
          <img
            src="https://randomuser.me/api/portraits/men/32.jpg"
            alt="user"
            className="w-8 h-8 rounded-full border-2 border-[#181824] object-cover"
          />
          <img
            src="https://randomuser.me/api/portraits/women/44.jpg"
            alt="user"
            className="w-8 h-8 rounded-full border-2 border-[#181824] object-cover"
          />
          <img
            src="https://randomuser.me/api/portraits/men/54.jpg"
            alt="user"
            className="w-8 h-8 rounded-full border-2 border-[#181824] object-cover"
          />
          <img
            src="https://randomuser.me/api/portraits/women/68.jpg"
            alt="user"
            className="w-8 h-8 rounded-full border-2 border-[#181824] object-cover"
          />
        </div>
      </div>
    </div>
  )
}

interface SignUp1Props {
  name: string
  email: string
  password: string
  passwordConfirmation: string
  error?: string
  processing?: boolean
  onNameChange: (value: string) => void
  onEmailChange: (value: string) => void
  onPasswordChange: (value: string) => void
  onPasswordConfirmationChange: (value: string) => void
  onSubmit: () => void
  status?: string
}

const SignUp1 = ({
  name,
  email,
  password,
  passwordConfirmation,
  error,
  processing,
  onNameChange,
  onEmailChange,
  onPasswordChange,
  onPasswordConfirmationChange,
  onSubmit,
  status,
}: SignUp1Props) => {
  const [localError, setLocalError] = React.useState("")

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  }

  const handleSignUp = () => {
    if (!name || !email || !password || !passwordConfirmation) {
      setLocalError("Please fill in all fields.")
      return
    }
    if (!validateEmail(email)) {
      setLocalError("Please enter a valid email address.")
      return
    }
    if (password !== passwordConfirmation) {
      setLocalError("Passwords do not match.")
      return
    }
    if (password.length < 8) {
      setLocalError("Password must be at least 8 characters.")
      return
    }
    setLocalError("")
    onSubmit()
  }

  const displayError = localError || error

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#121212] relative overflow-hidden w-full rounded-xl">
      <div className="relative z-10 w-full max-w-sm rounded-3xl bg-gradient-to-r from-[#ffffff10] to-[#121212] backdrop-blur-sm shadow-2xl p-8 flex flex-col items-center">
        <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap" rel="stylesheet" />
        <h2 className="text-5xl mb-8 text-center text-white" style={{ fontFamily: "'Dancing Script', cursive", fontWeight: 700 }}>
          DocNow
        </h2>

        {status && (
          <div className="w-full mb-4 text-sm font-medium text-green-400 text-center">
            {status}
          </div>
        )}

        <div className="flex flex-col w-full gap-4">
          <div className="w-full flex flex-col gap-3">
            <input
              placeholder="Full Name"
              type="text"
              value={name}
              className="w-full px-5 py-3 rounded-xl bg-white/10 text-white placeholder-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-gray-400"
              onChange={(e) => {
                setLocalError("")
                onNameChange(e.target.value)
              }}
            />
            <input
              placeholder="Email"
              type="email"
              value={email}
              className="w-full px-5 py-3 rounded-xl bg-white/10 text-white placeholder-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-gray-400"
              onChange={(e) => {
                setLocalError("")
                onEmailChange(e.target.value)
              }}
            />
            <input
              placeholder="Password"
              type="password"
              value={password}
              className="w-full px-5 py-3 rounded-xl bg-white/10 text-white placeholder-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-gray-400"
              onChange={(e) => {
                setLocalError("")
                onPasswordChange(e.target.value)
              }}
            />
            <input
              placeholder="Confirm Password"
              type="password"
              value={passwordConfirmation}
              className="w-full px-5 py-3 rounded-xl bg-white/10 text-white placeholder-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-gray-400"
              onChange={(e) => {
                setLocalError("")
                onPasswordConfirmationChange(e.target.value)
              }}
            />
            {displayError && (
              <div className="text-sm text-red-400 text-left">{displayError}</div>
            )}
          </div>
          <hr className="opacity-10" />
          <div>
            <button
              onClick={handleSignUp}
              disabled={processing}
              className="w-full bg-white/10 text-white font-medium px-5 py-3 rounded-full shadow hover:bg-white/20 transition mb-3 text-sm disabled:opacity-50"
            >
              {processing ? "Creating account..." : "Create account"}
            </button>
            <a
              href={route("auth.google.redirect")}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-b from-[#232526] to-[#2d2e30] rounded-full px-5 py-3 font-medium text-white shadow hover:brightness-110 transition mb-2 text-sm"
            >
              <img
                src="https://www.svgrepo.com/show/475656/google-color.svg"
                alt="Google"
                className="w-5 h-5"
              />
              Sign up with Google
            </a>
            <div className="w-full text-center mt-2">
              <span className="text-xs text-gray-400">
                Already have an account?{" "}
                <a
                  href={route("login")}
                  className="underline text-white/80 hover:text-white"
                >
                  Sign in
                </a>
              </span>
            </div>
          </div>
        </div>
      </div>
      <div className="relative z-10 mt-12 flex flex-col items-center text-center">
        <p className="text-gray-400 text-sm mb-2">
          Join <span className="font-medium text-white">thousands</span> of
          patients and doctors already using DocNow.
        </p>
        <div className="flex -space-x-2">
          <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="user" className="w-8 h-8 rounded-full border-2 border-[#181824] object-cover" />
          <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="user" className="w-8 h-8 rounded-full border-2 border-[#181824] object-cover" />
          <img src="https://randomuser.me/api/portraits/men/54.jpg" alt="user" className="w-8 h-8 rounded-full border-2 border-[#181824] object-cover" />
          <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="user" className="w-8 h-8 rounded-full border-2 border-[#181824] object-cover" />
        </div>
      </div>
    </div>
  )
}

export { SignIn1, SignUp1 }
