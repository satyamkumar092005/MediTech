import { router } from '@inertiajs/react';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface PaginationLink {
    url: string | null;
    label: string;
    active: boolean;
}

interface PaginationProps {
    links: PaginationLink[];
    meta?: { current_page: number; last_page: number; from: number; to: number; total: number };
}

export default function Pagination({ links, meta }: PaginationProps) {
    if (!links || links.length <= 3) return null;

    const handlePage = (url: string) => {
        router.get(url, {}, { preserveState: true, preserveScroll: true });
    };

    return (
        <div className="flex flex-col items-center gap-2 mt-6">
            {meta && (
                <p className="text-sm text-muted-foreground">
                    Showing {meta.from}–{meta.to} of {meta.total}
                </p>
            )}
            <div className="flex items-center gap-1">
                {links.map((link, i) => {
                    if (link.label.includes('Previous')) {
                        return (
                            <Button
                                key={i}
                                variant="outline"
                                size="icon"
                                disabled={!link.url}
                                onClick={() => link.url && handlePage(link.url)}
                            >
                                <ChevronLeft className="h-4 w-4" />
                            </Button>
                        );
                    }
                    if (link.label.includes('Next')) {
                        return (
                            <Button
                                key={i}
                                variant="outline"
                                size="icon"
                                disabled={!link.url}
                                onClick={() => link.url && handlePage(link.url)}
                            >
                                <ChevronRight className="h-4 w-4" />
                            </Button>
                        );
                    }
                    return (
                        <Button
                            key={i}
                            variant={link.active ? 'default' : 'outline'}
                            size="sm"
                            disabled={!link.url}
                            onClick={() => link.url && handlePage(link.url)}
                            className="min-w-[36px]"
                        >
                            {link.label}
                        </Button>
                    );
                })}
            </div>
        </div>
    );
}
