import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Sparkles, Loader2 } from 'lucide-react';
import axios from 'axios';

export function SymptomChecker() {
    const [symptoms, setSymptoms] = useState('');
    const [loading, setLoading] = useState(false);
    const [summary, setSummary] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleCheck = async () => {
        if (!symptoms.trim()) return;
        setLoading(true);
        setError(null);
        setSummary(null);

        try {
            const res = await axios.post('/patient/gemini/symptom-check', { symptoms });
            setSummary(res.data.summary);
        } catch (e: any) {
            setError(e.response?.data?.error || 'Failed to analyze symptoms.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card>
            <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-blue-400" />
                    AI Symptom Pre-Screening
                </CardTitle>
                <p className="text-sm text-muted-foreground">Describe your symptoms to get an AI-generated medical abstract and recommendation on which specialist to see.</p>
            </CardHeader>
            <CardContent>
                {!summary ? (
                    <div className="space-y-3">
                        <Textarea
                            placeholder="I have a headache, mild fever, and a sore throat since yesterday..."
                            value={symptoms}
                            onChange={(e) => setSymptoms(e.target.value)}
                            className="resize-none"
                            rows={3}
                        />
                        {error && <p className="text-xs text-destructive">{error}</p>}
                        <Button 
                            onClick={handleCheck} 
                            disabled={loading || !symptoms.trim()}
                        >
                            {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : 'Analyze Symptoms'}
                        </Button>
                    </div>
                ) : (
                    <div className="space-y-4">
                        <div className="bg-muted/50 p-4 rounded-md border text-sm whitespace-pre-wrap leading-relaxed">
                            {summary}
                        </div>
                        <Button variant="outline" onClick={() => setSummary(null)}>
                            Start Over
                        </Button>
                        <p className="text-xs text-muted-foreground">
                            * You can copy this summary to your appointment notes when booking.
                        </p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}
